package com.example

import com.example.data.supabase.SupabaseService
import org.junit.Assert.*
import org.junit.Test

/**
 * Local unit tests verifying Supabase initialization, database schema generation,
 * and environmental configuration logic.
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testSupabaseDatabaseSchemaSQLContainsAllRequiredTables() {
        val schemaSql = SupabaseService.getDatabaseSchemaSQL()
        
        // Assert that the generated SQL is not blank
        assertNotNull(schemaSql)
        assertTrue(schemaSql.isNotBlank())

        // Verify that all core local databases are correctly declared as tables
        assertTrue("SQL should create users table", schemaSql.contains("create table if not exists public.users"))
        assertTrue("SQL should create messages table", schemaSql.contains("create table if not exists public.messages"))
        assertTrue("SQL should create groups table", schemaSql.contains("create table if not exists public.groups"))
        assertTrue("SQL should create reports table", schemaSql.contains("create table if not exists public.reports"))

        // Verify key column constraints are present
        assertTrue("SQL should contain isSuperAdmin mapping", schemaSql.contains("\"isSuperAdmin\" boolean"))
        assertTrue("SQL should contain isDeletedForAll mapping", schemaSql.contains("\"isDeletedForAll\" boolean"))
        assertTrue("SQL should contain status mapping", schemaSql.contains("status text"))
    }

    @Test
    fun testSupabaseConfigDetectionWithDefaultFallbackValues() {
        // If BuildConfig is using fallback template values (like "YOUR_SUPABASE_URL"),
        // the service should intelligently report isConfigured = false.
        val defaultUrl = "YOUR_SUPABASE_URL"
        val defaultKey = "YOUR_SUPABASE_ANON_KEY"
        
        val isConfigured = defaultUrl.isNotBlank() && 
                           !defaultUrl.contains("YOUR_SUPABASE") && 
                           defaultKey.isNotBlank() && 
                           !defaultKey.contains("YOUR_SUPABASE")

        assertFalse("Service should not be active with placeholder credentials", isConfigured)
    }
}
