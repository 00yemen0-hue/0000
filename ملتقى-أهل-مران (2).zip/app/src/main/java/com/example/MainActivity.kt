package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.components.YemeniEmblem
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = viewModel.isDarkMode) {
                // Main Navigation and layout
                var currentScreen by remember { mutableStateOf("auth") } // auth, main_chat, private_chat, profile, settings, admin, group_management
                var selectedProfileUser by remember { mutableStateOf<User?>(null) }

                val currentUser = viewModel.currentUser

                // Automatically navigate to auth screen if logged out
                LaunchedEffect(currentUser) {
                    if (currentUser == null) {
                        currentScreen = "auth"
                    } else if (currentScreen == "auth") {
                        currentScreen = "main_chat"
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (currentUser == null) {
                        AuthScreens(viewModel = viewModel, onAuthSuccess = {
                            currentScreen = "main_chat"
                        })
                    } else if (currentUser.isFrozen) {
                        // Secure Account Frozen Overlay (Blocks illegal access to blocked users)
                        AccountFrozenOverlay(viewModel = viewModel)
                    } else {
                        // Authorized session flow
                        Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                            when (screen) {
                                "main_chat" -> {
                                    MainChatScreens(
                                        viewModel = viewModel,
                                        onNavigateToProfile = { user ->
                                            selectedProfileUser = user
                                            currentScreen = "profile"
                                        },
                                        onNavigateToSettings = { currentScreen = "settings" },
                                        onNavigateToAdmin = { currentScreen = "admin" },
                                        onNavigateToGroupManagement = { currentScreen = "group_management" }
                                    )
                                }
                                "private_chat" -> {
                                    PrivateChatScreen(
                                        viewModel = viewModel,
                                        onBack = { currentScreen = "main_chat" }
                                    )
                                }
                                "profile" -> {
                                    ProfileScreen(
                                        viewModel = viewModel,
                                        profileUser = selectedProfileUser ?: currentUser,
                                        onBack = { currentScreen = "main_chat" },
                                        onStartPrivateChat = { targetUser ->
                                            viewModel.setChatId(
                                                chatId = "private_${minOf(currentUser.id, targetUser.id)}_${maxOf(currentUser.id, targetUser.id)}",
                                                privateUser = targetUser
                                            )
                                            currentScreen = "private_chat"
                                        }
                                    )
                                }
                                "settings" -> {
                                    SettingsScreen(
                                        viewModel = viewModel,
                                        onBack = { currentScreen = "main_chat" }
                                    )
                                }
                                "admin" -> {
                                    AdminScreens(
                                        viewModel = viewModel,
                                        onBack = { currentScreen = "main_chat" }
                                    )
                                }
                                "group_management" -> {
                                    GroupManagementScreen(
                                        viewModel = viewModel,
                                        onBack = { currentScreen = "main_chat" }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AccountFrozenOverlay(viewModel: ChatViewModel) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = colors.errorContainer.copy(alpha = 0.2f)),
            border = BorderStroke(1.dp, colors.error.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                YemeniEmblem(modifier = Modifier.size(100.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Icon(Icons.Default.Lock, contentDescription = null, tint = colors.error, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "الحساب مجمد إدارياً",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = colors.error)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "عذراً، لقد تم تجميد هذا الحساب مؤقتاً بواسطة الإدارة العامة لملتقى أهل مران لمخالفته شروط وقواعد النشر في الملتقى السلمي العام.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium.copy(color = colors.onSurfaceVariant)
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.logoutUser() },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.error),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("الخروج وتسجيل حساب آخر")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
