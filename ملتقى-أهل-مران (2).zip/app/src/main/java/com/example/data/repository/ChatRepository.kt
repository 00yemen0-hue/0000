package com.example.data.repository

import com.example.data.database.ChatDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class ChatRepository(private val chatDao: ChatDao) {

    // Users
    val allUsers: Flow<List<User>> = chatDao.getAllUsers()

    suspend fun getUserByEmail(email: String): User? = chatDao.getUserByEmail(email)

    suspend fun getUserById(id: Int): User? = chatDao.getUserById(id)

    suspend fun insertUser(user: User): Long = chatDao.insertUser(user)

    suspend fun updateUser(user: User) = chatDao.updateUser(user)

    // Messages
    fun getMessagesForChat(chatId: String): Flow<List<Message>> = chatDao.getMessagesForChat(chatId)

    suspend fun getMessageById(id: Int): Message? = chatDao.getMessageById(id)

    suspend fun insertMessage(message: Message): Long = chatDao.insertMessage(message)

    suspend fun updateMessage(message: Message) = chatDao.updateMessage(message)

    suspend fun deleteMessage(message: Message) = chatDao.deleteMessage(message)

    fun getPinnedMessagesForChat(chatId: String): Flow<List<Message>> = chatDao.getPinnedMessagesForChat(chatId)

    // Groups
    val allGroups: Flow<List<GroupDetail>> = chatDao.getAllGroups()

    suspend fun getGroupById(id: Int): GroupDetail? = chatDao.getGroupById(id)

    suspend fun insertGroup(group: GroupDetail): Long = chatDao.insertGroup(group)

    suspend fun updateGroup(group: GroupDetail) = chatDao.updateGroup(group)

    suspend fun deleteGroup(group: GroupDetail) = chatDao.deleteGroup(group)

    // Logs
    val allLogs: Flow<List<AdminLog>> = chatDao.getAllLogs()

    suspend fun insertLog(log: AdminLog) = chatDao.insertLog(log)

    // Reports
    val allReports: Flow<List<Report>> = chatDao.getAllReports()

    suspend fun insertReport(report: Report) = chatDao.insertReport(report)

    suspend fun updateReport(report: Report) = chatDao.updateReport(report)
}
