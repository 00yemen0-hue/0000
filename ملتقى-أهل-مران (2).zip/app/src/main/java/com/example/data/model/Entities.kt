package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val email: String,
    val password: String,
    val name: String,
    val avatarUrl: String = "avatar_1", // Default avatar identifier
    val coverUrl: String = "cover_default",
    val bio: String = "عضو في ملتقى أهل مران",
    val status: String = "متصل", // "متصل", "مشغول", "غير متصل"
    val lastSeen: Long = System.currentTimeMillis(),
    val isSuperAdmin: Boolean = false,
    val isFrozen: Boolean = false
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chatId: String, // "main_group", "private_X_Y", "group_X"
    val senderId: Int,
    val senderName: String,
    val senderAvatar: String,
    val content: String,
    val messageType: String = "TEXT", // "TEXT", "IMAGE", "VIDEO", "FILE", "AUDIO", "LOCATION", "CALL_AUDIO", "CALL_VIDEO"
    val mediaUri: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isEdited: Boolean = false,
    val replyToId: Int? = null,
    val replyToContent: String? = null,
    val isPinned: Boolean = false,
    val reactions: String = "", // e.g., "👍,❤️" (reactions attached)
    val isDeletedForAll: Boolean = false
)

@Entity(tableName = "groups")
data class GroupDetail(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val iconUrl: String = "group_default",
    val adminIds: String = "", // Comma-separated user IDs
    val memberIds: String = "" // Comma-separated user IDs
)

@Entity(tableName = "admin_logs")
data class AdminLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val adminName: String,
    val action: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reports")
data class Report(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val reportedBy: String,
    val reportedUser: String,
    val reason: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "معلق" // "معلق", "تم الحل"
)
