package com.example.data.supabase

import com.example.data.model.*
import retrofit2.Response
import retrofit2.http.*

data class SupabaseSignUpRequest(
    val email: String,
    val password: String,
    val data: Map<String, String>? = null
)

data class SupabaseSignInRequest(
    val email: String,
    val password: String
)

data class SupabaseAuthUser(
    val id: String,
    val email: String?,
    val user_metadata: Map<String, String>? = null
)

data class SupabaseAuthResponse(
    val access_token: String?,
    val token_type: String?,
    val expires_in: Long?,
    val refresh_token: String?,
    val user: SupabaseAuthUser?
)

data class SupabaseErrorResponse(
    val msg: String?,
    val error_description: String?,
    val error: String?,
    val code: Int?
)

interface SupabaseApi {
    @POST("auth/v1/signup")
    suspend fun signUp(
        @Body request: SupabaseSignUpRequest
    ): Response<SupabaseAuthResponse>

    @POST("auth/v1/token")
    suspend fun signIn(
        @Query("grant_type") grantType: String = "password",
        @Body request: SupabaseSignInRequest
    ): Response<SupabaseAuthResponse>

    @GET("rest/v1/users")
    suspend fun getUsers(
        @Query("select") select: String = "*"
    ): List<User>

    @POST("rest/v1/users")
    @Headers("Prefer: resolution=merge-duplicates")
    suspend fun upsertUsers(
        @Body users: List<User>
    ): Response<Unit>

    @GET("rest/v1/messages")
    suspend fun getMessages(
        @Query("select") select: String = "*",
        @Query("order") order: String = "timestamp.asc"
    ): List<Message>

    @POST("rest/v1/messages")
    @Headers("Prefer: resolution=merge-duplicates")
    suspend fun upsertMessages(
        @Body messages: List<Message>
    ): Response<Unit>

    @GET("rest/v1/groups")
    suspend fun getGroups(
        @Query("select") select: String = "*"
    ): List<GroupDetail>

    @POST("rest/v1/groups")
    @Headers("Prefer: resolution=merge-duplicates")
    suspend fun upsertGroups(
        @Body groups: List<GroupDetail>
    ): Response<Unit>

    @GET("rest/v1/reports")
    suspend fun getReports(
        @Query("select") select: String = "*"
    ): List<Report>

    @POST("rest/v1/reports")
    @Headers("Prefer: resolution=merge-duplicates")
    suspend fun upsertReports(
        @Body reports: List<Report>
    ): Response<Unit>

    @GET("rest/v1/admin_logs")
    suspend fun getAdminLogs(
        @Query("select") select: String = "*"
    ): List<AdminLog>

    @POST("rest/v1/admin_logs")
    @Headers("Prefer: resolution=merge-duplicates")
    suspend fun upsertAdminLogs(
        @Body logs: List<AdminLog>
    ): Response<Unit>
}

