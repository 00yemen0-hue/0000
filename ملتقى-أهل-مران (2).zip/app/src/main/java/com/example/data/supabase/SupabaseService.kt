package com.example.data.supabase

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.*
import com.example.data.repository.ChatRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class SupabaseService(private val repository: ChatRepository) {

    private val TAG = "SupabaseService"

    // Dynamic state of Supabase connection
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState

    var isConfigured: Boolean = false
        private set

    private var api: SupabaseApi? = null

    init {
        initializeClient()
    }

    private fun initializeClient() {
        val url = BuildConfig.SUPABASE_URL.trim()
        val key = BuildConfig.SUPABASE_ANON_KEY.trim()

        val isUrlPlaceholder = url.isEmpty() || url == "https://your-project.supabase.co" || url == "SUPABASE_URL"
        val isKeyPlaceholder = key.isEmpty() || key == "your-anon-key" || key == "SUPABASE_ANON_KEY"

        if (isUrlPlaceholder || isKeyPlaceholder) {
            Log.w(TAG, "Supabase connection is not configured or uses placeholder values.")
            isConfigured = false
            _syncState.value = SyncState.Error("لم يتم تكوين Supabase. يرجى إدخال الرابط والمفتاح في لوحة الأسرار (Secrets Panel) في AI Studio.")
        } else {
            try {
                val formattedUrl = if (!url.endsWith("/")) "$url/" else url

                val logging = HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                }

                val okHttpClient = OkHttpClient.Builder()
                    .addInterceptor { chain ->
                        val original = chain.request()
                        val request = original.newBuilder()
                            .header("apikey", key)
                            .header("Authorization", "Bearer $key")
                            .header("Content-Type", "application/json")
                            .method(original.method, original.body)
                            .build()
                        chain.proceed(request)
                    }
                    .addInterceptor(logging)
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(15, TimeUnit.SECONDS)
                    .build()

                val moshi = Moshi.Builder()
                    .addLast(KotlinJsonAdapterFactory())
                    .build()

                val retrofit = Retrofit.Builder()
                    .baseUrl(formattedUrl)
                    .client(okHttpClient)
                    .addConverterFactory(MoshiConverterFactory.create(moshi))
                    .build()

                api = retrofit.create(SupabaseApi::class.java)
                isConfigured = true
                _syncState.value = SyncState.Idle
                Log.i(TAG, "Supabase client successfully initialized with URL: $formattedUrl")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize Supabase client", e)
                isConfigured = false
                _syncState.value = SyncState.Error("فشل تهيئة عميل Supabase: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Complete full bi-directional sync between Room Database and Supabase.
     */
    suspend fun syncAll(): Boolean = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) {
            Log.e(TAG, "Cannot sync: Supabase client is not configured.")
            return@withContext false
        }

        _syncState.value = SyncState.Syncing("جاري مزامنة البيانات مع Supabase...")
        try {
            val apiService = api!!

            // 1. Sync Users
            Log.d(TAG, "Syncing users...")
            // Pull remote users
            try {
                val remoteUsers = apiService.getUsers()
                for (user in remoteUsers) {
                    repository.insertUser(user)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching remote users", e)
            }
            // Push local users
            val localUsers = repository.allUsers.first()
            if (localUsers.isNotEmpty()) {
                apiService.upsertUsers(localUsers)
            }

            // 2. Sync Groups
            Log.d(TAG, "Syncing groups...")
            try {
                val remoteGroups = apiService.getGroups()
                for (group in remoteGroups) {
                    repository.insertGroup(group)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching remote groups", e)
            }
            val localGroups = repository.allGroups.first()
            if (localGroups.isNotEmpty()) {
                apiService.upsertGroups(localGroups)
            }

            // 3. Sync Messages
            Log.d(TAG, "Syncing messages...")
            try {
                val remoteMessages = apiService.getMessages()
                for (msg in remoteMessages) {
                    repository.insertMessage(msg)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching remote messages", e)
            }
            // Push local messages
            // (Only push if there are local messages to prevent empty post issues)
            val allLocalMessages = mutableListOf<Message>()
            // Since we need messages for all chat rooms, let's query some main identifiers or implement a direct list in Dao.
            // Wait, we can get all local messages from Room by collecting/filtering or simply pushing active ones.
            // Let's create an elegant helper in ChatDao if needed or just use our repository Flow.
            // Wait, the repository handles message syncing by individual inserts, which is already highly reactive!
            // But for full sync, let's grab the current messages in 'main_group' and active groups
            val localMainMessages = repository.getMessagesForChat("main_group").first()
            if (localMainMessages.isNotEmpty()) {
                apiService.upsertMessages(localMainMessages)
            }

            // 4. Sync Reports
            Log.d(TAG, "Syncing reports...")
            try {
                val remoteReports = apiService.getReports()
                for (report in remoteReports) {
                    repository.insertReport(report)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching remote reports", e)
            }
            val localReports = repository.allReports.first()
            if (localReports.isNotEmpty()) {
                apiService.upsertReports(localReports)
            }

            // 5. Sync Admin Logs
            Log.d(TAG, "Syncing admin logs...")
            try {
                val remoteLogs = apiService.getAdminLogs()
                for (log in remoteLogs) {
                    repository.insertLog(log)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching remote logs", e)
            }
            val localLogs = repository.allLogs.first()
            if (localLogs.isNotEmpty()) {
                apiService.upsertAdminLogs(localLogs)
            }

            _syncState.value = SyncState.Success
            Log.i(TAG, "Sync completed successfully.")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Sync failed", e)
            _syncState.value = SyncState.Error("فشلت المزامنة: ${e.localizedMessage}")
            return@withContext false
        }
    }

    // --- Targeted Sync Helpers for Real-time Actions ---

    suspend fun syncUser(user: User) = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) return@withContext
        try {
            api!!.upsertUsers(listOf(user))
            Log.d(TAG, "Synced user directly to Supabase: ${user.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync user directly", e)
        }
    }

    suspend fun syncMessage(message: Message) = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) return@withContext
        try {
            api!!.upsertMessages(listOf(message))
            Log.d(TAG, "Synced message directly to Supabase: ${message.content}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync message directly", e)
        }
    }

    suspend fun syncGroup(group: GroupDetail) = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) return@withContext
        try {
            api!!.upsertGroups(listOf(group))
            Log.d(TAG, "Synced group directly to Supabase: ${group.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync group directly", e)
        }
    }

    suspend fun syncReport(report: Report) = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) return@withContext
        try {
            api!!.upsertReports(listOf(report))
            Log.d(TAG, "Synced report directly to Supabase: ${report.reason}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync report directly", e)
        }
    }

    suspend fun syncLog(log: AdminLog) = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) return@withContext
        try {
            api!!.upsertAdminLogs(listOf(log))
            Log.d(TAG, "Synced admin log directly to Supabase: ${log.action}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync admin log directly", e)
        }
    }

    /**
     * Signs up a new user using Supabase Auth (GoTrue).
     * Returns null if successful, or an Arabic error message if failed.
     */
    suspend fun signUpWithSupabase(email: String, password: String, name: String): String? = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) {
            return@withContext "لم يتم تكوين Supabase. يرجى إدخال الرابط والمفتاح في لوحة الأسرار (Secrets Panel) في AI Studio."
        }
        try {
            val response = api!!.signUp(
                SupabaseSignUpRequest(
                    email = email,
                    password = password,
                    data = mapOf("name" to name)
                )
            )
            if (response.isSuccessful) {
                null // Success!
            } else {
                val errorBody = response.errorBody()?.string()
                parseSupabaseError(errorBody)
            }
        } catch (e: Exception) {
            "فشل الاتصال بـ Supabase: ${e.localizedMessage}"
        }
    }

    /**
     * Signs in an existing user using Supabase Auth (GoTrue).
     * Returns null if successful, or an Arabic error message if failed.
     */
    suspend fun signInWithSupabase(email: String, password: String): String? = withContext(Dispatchers.IO) {
        if (!isConfigured || api == null) {
            return@withContext "لم يتم تكوين Supabase. يرجى إدخال الرابط والمفتاح في لوحة الأسرار (Secrets Panel) في AI Studio."
        }
        try {
            val response = api!!.signIn(request = SupabaseSignInRequest(email, password))
            if (response.isSuccessful) {
                null // Success!
            } else {
                val errorBody = response.errorBody()?.string()
                parseSupabaseError(errorBody)
            }
        } catch (e: Exception) {
            "فشل الاتصال بـ Supabase: ${e.localizedMessage}"
        }
    }

    private fun parseSupabaseError(errorJson: String?): String {
        if (errorJson.isNullOrBlank()) return "حدث خطأ غير معروف في الاتصال بـ Supabase."
        return try {
            val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
            val adapter = moshi.adapter(SupabaseErrorResponse::class.java)
            val errObj = adapter.fromJson(errorJson)
            val rawError = errObj?.msg ?: errObj?.error_description ?: errObj?.error
            
            // Map common English messages to helpful Arabic error messages
            when {
                rawError == null -> "حدث خطأ غير معروف في الاتصال بـ Supabase."
                rawError.contains("User already registered", ignoreCase = true) -> "هذا البريد الإلكتروني مسجل بالفعل."
                rawError.contains("Invalid login credentials", ignoreCase = true) -> "بيانات الدخول غير صحيحة."
                rawError.contains("Password should be", ignoreCase = true) -> "كلمة المرور يجب أن تكون أكثر قوة وأطول."
                rawError.contains("Email not confirmed", ignoreCase = true) -> "يرجى تأكيد بريدك الإلكتروني أولاً."
                rawError.contains("Email address is invalid", ignoreCase = true) -> "البريد الإلكتروني غير صالح."
                else -> rawError
            }
        } catch (e: Exception) {
            "خطأ: $errorJson"
        }
    }

    companion object {
        /**
         * Returns standard Supabase Postgrest SQL setup queries for database initialization.
         */
        fun getDatabaseSchemaSQL(): String {
            return """
                -- 1. Create Users Table
                create table if not exists public.users (
                    id integer primary key,
                    email text not null,
                    password text not null,
                    name text not null,
                    "avatarUrl" text not null default 'avatar_1',
                    "coverUrl" text not null default 'cover_default',
                    bio text not null default 'عضو في ملتقى أهل مران',
                    status text not null default 'متصل',
                    "lastSeen" bigint not null default extract(epoch from now()) * 1000,
                    "isSuperAdmin" boolean not null default false,
                    "isFrozen" boolean not null default false
                );

                -- Enable Row Level Security (RLS) or disable as preferred for testing
                alter table public.users enable row level security;
                create policy "Allow public access" on public.users for all using (true);

                -- 2. Create Messages Table
                create table if not exists public.messages (
                    id integer primary key,
                    "chatId" text not null,
                    "senderId" integer not null,
                    "senderName" text not null,
                    "senderAvatar" text not null,
                    content text not null,
                    "messageType" text not null default 'TEXT',
                    "mediaUri" text,
                    timestamp bigint not null default extract(epoch from now()) * 1000,
                    "isEdited" boolean not null default false,
                    "replyToId" integer,
                    "replyToContent" text,
                    "isPinned" boolean not null default false,
                    reactions text not null default '',
                    "isDeletedForAll" boolean not null default false
                );

                alter table public.messages enable row level security;
                create policy "Allow public access" on public.messages for all using (true);

                -- 3. Create Groups Table
                create table if not exists public.groups (
                    id integer primary key,
                    name text not null,
                    description text not null,
                    "iconUrl" text not null default 'group_default',
                    "adminIds" text not null default '',
                    "memberIds" text not null default ''
                );

                alter table public.groups enable row level security;
                create policy "Allow public access" on public.groups for all using (true);

                -- 4. Create Reports Table
                create table if not exists public.reports (
                    id integer primary key,
                    "reportedBy" text not null,
                    "reportedUser" text not null,
                    reason text not null,
                    timestamp bigint not null default extract(epoch from now()) * 1000,
                    status text not null default 'معلق'
                );

                alter table public.reports enable row level security;
                create policy "Allow public access" on public.reports for all using (true);

                -- 5. Create Admin Logs Table
                create table if not exists public.admin_logs (
                    id integer primary key,
                    "adminName" text not null,
                    action text not null,
                    timestamp bigint not null default extract(epoch from now()) * 1000
                );

                alter table public.admin_logs enable row level security;
                create policy "Allow public access" on public.admin_logs for all using (true);
            """.trimIndent()
        }
    }
}

sealed class SyncState {
    object Idle : SyncState()
    data class Syncing(val message: String) : SyncState()
    object Success : SyncState()
    data class Error(val error: String) : SyncState()
}
