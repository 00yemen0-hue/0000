package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Message
import com.example.data.model.User
import com.example.ui.components.CustomAvatarView
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateChatScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val activeUser = viewModel.activePrivateUser ?: return
    val messages by viewModel.messages.collectAsState()
    var textInput by remember { mutableStateOf("") }
    
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val colors = MaterialTheme.colorScheme

    // Scroll to bottom
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                CustomAvatarView(
                                    modifier = Modifier.size(38.dp),
                                    skinColorHex = if (activeUser.avatarUrl.startsWith("#")) activeUser.avatarUrl else "#D2B48C"
                                )
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .align(Alignment.BottomEnd)
                                        .background(
                                            color = if (activeUser.status == "متصل") Color.Green else Color.Gray,
                                            shape = CircleShape
                                        )
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(activeUser.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(
                                    text = if (activeUser.status == "متصل") "متصل الآن" else "آخر ظهور: مؤخراً",
                                    style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f))
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        // Audio Call Button
                        IconButton(onClick = { viewModel.startCall(activeUser, "AUDIO") }) {
                            Icon(Icons.Default.Phone, contentDescription = "مكالمة صوتية", tint = colors.primary)
                        }
                        // Video Call Button
                        IconButton(onClick = { viewModel.startCall(activeUser, "VIDEO") }) {
                            Icon(Icons.Default.Videocam, contentDescription = "مكالمة فيديو", tint = colors.primary)
                        }
                    }
                )
            },
            bottomBar = {
                Surface(
                    modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            viewModel.sendMessage("مشاركة موقع جغرافي حي 📍", "LOCATION", "16.8903,43.4320")
                        }) {
                            Icon(Icons.Default.Place, contentDescription = "مشاركة الموقع", tint = colors.primary)
                        }
                        
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("اكتب رسالة خاصة آمنة...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("private_chat_input_field"),
                            shape = RoundedCornerShape(24.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = colors.surfaceColorAtElevation(1.dp),
                                unfocusedContainerColor = colors.surfaceColorAtElevation(1.dp)
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    viewModel.sendMessage(textInput)
                                    textInput = ""
                                }
                            },
                            enabled = textInput.isNotBlank(),
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = colors.primary),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال")
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(colors.surfaceColorAtElevation(1.dp))
            ) {
                if (messages.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = colors.primary.copy(alpha = 0.2f),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "المحادثات الخاصة مشفرة وآمنة تماماً.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = colors.onSurface.copy(alpha = 0.5f))
                        )
                        Text(
                            "ابدأ الحوار الآن بكل طمأنينة.",
                            style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.4f))
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages) { message ->
                            MessageBubble(
                                message = message,
                                isMe = message.senderId == viewModel.currentUser?.id,
                                colors = colors,
                                viewModel = viewModel,
                                onReply = {},
                                onEdit = {
                                    textInput = message.content
                                },
                                onProfileClick = {}
                            )
                        }
                    }
                }
            }
        }

        // Animated Call Screen Overlay (Direct Native Implementation of Calling feature)
        AnimatedVisibility(
            visible = viewModel.isCallActive,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0C1014))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Call Status header
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 40.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = colors.primary.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color.Red, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (viewModel.activeCallType == "AUDIO") "مكالمة صوتية مشفرة" else "مكالمة مرئية عالية الدقة",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(24.dp))

                        // Big Profile Turban Avatar
                        Box(contentAlignment = Alignment.Center) {
                            // Pulsating animation back rings
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .background(colors.primary.copy(alpha = 0.1f), CircleShape)
                            )
                            CustomAvatarView(
                                modifier = Modifier
                                    .size(130.dp)
                                    .clip(CircleShape),
                                skinColorHex = if (activeUser.avatarUrl.startsWith("#")) activeUser.avatarUrl else "#D2B48C"
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = activeUser.name,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = Color.White)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = String.format("%02d:%02d", viewModel.callDuration / 60, viewModel.callDuration % 60),
                            color = colors.primary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Simulated Camera Preview Screen for video call
                    if (viewModel.activeCallType == "VIDEO" && !viewModel.isCallVideoPaused) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.DarkGray)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(32.dp))
                                Text("جاري بث الكاميرا الأمامية المباشرة...", color = Color.White, fontSize = 10.sp)
                            }
                        }
                    } else if (viewModel.activeCallType == "AUDIO") {
                        // Dynamic equalizer lines visual representation
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.height(60.dp)
                        ) {
                            val waveHeights = listOf(20, 45, 15, 30, 50, 25, 40, 10, 35, 48)
                            waveHeights.forEach { h ->
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height(h.dp)
                                        .background(colors.primary, RoundedCornerShape(1.5.dp))
                                )
                            }
                        }
                    }

                    // Control Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 30.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Mute button
                        FilledIconButton(
                            onClick = { viewModel.isCallMuted = !viewModel.isCallMuted },
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = if (viewModel.isCallMuted) colors.error else Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(
                                imageVector = if (viewModel.isCallMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }

                        // End Call Red Button
                        FilledIconButton(
                            onClick = { viewModel.endCall() },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Red),
                            modifier = Modifier.size(68.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "إنهاء المكالمة",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Camera Toggle button (for video) / speaker toggle (for audio)
                        FilledIconButton(
                            onClick = {
                                if (viewModel.activeCallType == "VIDEO") {
                                    viewModel.isCallVideoPaused = !viewModel.isCallVideoPaused
                                }
                            },
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = if (viewModel.isCallVideoPaused) colors.error else Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.size(54.dp),
                            enabled = viewModel.activeCallType == "VIDEO"
                        ) {
                            Icon(
                                imageVector = if (viewModel.activeCallType == "VIDEO") {
                                    if (viewModel.isCallVideoPaused) Icons.Default.VideocamOff else Icons.Default.Videocam
                                } else {
                                    Icons.Default.VolumeUp
                                },
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
