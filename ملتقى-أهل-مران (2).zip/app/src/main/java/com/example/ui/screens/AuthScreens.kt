package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.YemeniEmblem
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreens(
    viewModel: ChatViewModel,
    onAuthSuccess: () -> Unit
) {
    var isLoginMode by remember { mutableStateOf(true) }
    var isResetMode by remember { mutableStateOf(false) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var infoMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    var passwordVisible by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val colors = MaterialTheme.colorScheme

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        colors.background,
                        colors.surfaceColorAtElevation(4.dp)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
                .widthIn(max = 480.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Heritage Branding Logo
            YemeniEmblem(
                modifier = Modifier
                    .size(130.dp)
                    .padding(bottom = 16.dp),
                style = viewModel.appLogoState
            )

            Text(
                text = viewModel.appNameState,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = colors.primary,
                    letterSpacing = 1.sp
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "ملتقى الترابط والمحبة لأهل مران الأوفياء",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = colors.onSurface.copy(alpha = 0.6f)
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Auth Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = when {
                            isResetMode -> "إعادة تعيين كلمة المرور"
                            isLoginMode -> "تسجيل الدخول"
                            else -> "إنشاء حساب جديد"
                        },
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = colors.onSurface
                        ),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Messages Alert
                    errorMessage?.let {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = colors.errorContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Text(
                                text = it,
                                style = MaterialTheme.typography.bodyMedium.copy(color = colors.onErrorContainer),
                                modifier = Modifier.padding(12.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    infoMessage?.let {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = colors.secondaryContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Text(
                                text = it,
                                style = MaterialTheme.typography.bodyMedium.copy(color = colors.onSecondaryContainer),
                                modifier = Modifier.padding(12.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Name field (Sign up only)
                    if (!isLoginMode && !isResetMode) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("الاسم الكامل") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .testTag("register_name_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }

                    // Email field
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("البريد الإلكتروني") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .testTag("auth_email_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )

                    // Password field (Login / Sign up only)
                    if (!isResetMode) {
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .testTag("auth_password_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }

                    // Confirm Password (Sign up only)
                    if (!isLoginMode && !isResetMode) {
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it },
                            label = { Text("تأكيد كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    }

                    // Reset Mode Hint
                    if (isResetMode) {
                        Text(
                            text = "سنرسل لك رابط إعادة تعيين كلمة المرور عبر بريدك الإلكتروني.",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }

                    // Submit Button
                    Button(
                        onClick = {
                            if (isLoading) return@Button
                            errorMessage = null
                            infoMessage = null
                            if (email.isBlank()) {
                                errorMessage = "الرجاء إدخال البريد الإلكتروني"
                                return@Button
                            }

                            if (isResetMode) {
                                isLoading = true
                                scope.launch {
                                    delay(1000)
                                    infoMessage = "تم إرسال رابط إعادة التعيين إلى $email بنجاح! يرجى مراجعة بريدك."
                                    isLoading = false
                                    delay(4000)
                                    isResetMode = false
                                    isLoginMode = true
                                }
                            } else if (isLoginMode) {
                                if (password.isBlank()) {
                                    errorMessage = "الرجاء إدخال كلمة المرور"
                                    return@Button
                                }
                                isLoading = true
                                scope.launch {
                                    val error = viewModel.loginUser(email, password)
                                    isLoading = false
                                    if (error == null) {
                                        onAuthSuccess()
                                    } else {
                                        errorMessage = error
                                    }
                                }
                            } else {
                                // Sign Up Mode
                                if (name.isBlank()) {
                                    errorMessage = "الرجاء إدخال الاسم"
                                    return@Button
                                }
                                if (password.length < 3) {
                                    errorMessage = "كلمة المرور يجب أن تكون من 3 أحرف على الأقل"
                                    return@Button
                                }
                                if (password != confirmPassword) {
                                    errorMessage = "كلمات المرور غير متطابقة"
                                    return@Button
                                }
                                isLoading = true
                                scope.launch {
                                    val error = viewModel.registerUser(email, password, name)
                                    isLoading = false
                                    if (error == null) {
                                        onAuthSuccess()
                                    } else {
                                        errorMessage = error
                                    }
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("auth_submit_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = colors.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = when {
                                    isResetMode -> "إرسال رابط التعيين"
                                    isLoginMode -> "تسجيل الدخول"
                                    else -> "إنشاء الحساب وتفعيل العضوية"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    // Simple Error Message under the form
                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = colors.error,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Text Buttons Toggles
                    if (isResetMode) {
                        TextButton(onClick = {
                            isResetMode = false
                            isLoginMode = true
                            errorMessage = null
                            infoMessage = null
                        }) {
                            Text("العودة لتسجيل الدخول", color = colors.primary)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = {
                                isLoginMode = !isLoginMode
                                errorMessage = null
                                infoMessage = null
                            }) {
                                Text(
                                    text = if (isLoginMode) "إنشاء حساب جديد؟" else "لديك حساب بالفعل؟ دخول",
                                    color = colors.primary
                                )
                            }

                            if (isLoginMode) {
                                TextButton(onClick = {
                                    isResetMode = true
                                    errorMessage = null
                                    infoMessage = null
                                }) {
                                    Text("نسيت كلمة المرور؟", color = colors.onSurface.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
