package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
fun CustomAvatarView(
    modifier: Modifier = Modifier,
    skinColorHex: String = "#D2B48C",
    eyesType: String = "wide", // wide, gentle, squint
    beardStyle: String = "yemeni_beard", // yemeni_beard, mustach, clean, goatee
    beardColorHex: String = "#4A3728",
    turbanColorHex: String = "#800000",
    bgColorHex: String = "#0A5C36"
) {
    val skinColor = Color(android.graphics.Color.parseColor(skinColorHex))
    val beardColor = Color(android.graphics.Color.parseColor(beardColorHex))
    val turbanColor = Color(android.graphics.Color.parseColor(turbanColorHex))
    val bgColor = Color(android.graphics.Color.parseColor(bgColorHex))

    Canvas(modifier = modifier.aspectRatio(1f)) {
        val width = size.width
        val height = size.height
        val center = Offset(width / 2f, height / 2f)
        val radius = width * 0.48f

        // 1. Draw circular background
        drawCircle(color = bgColor, radius = radius, center = center)

        // 2. Draw Shoulders (Thobe)
        val thobePath = Path().apply {
            moveTo(width * 0.2f, height)
            quadraticBezierTo(width * 0.3f, height * 0.72f, width * 0.35f, height * 0.75f)
            lineTo(width * 0.65f, height * 0.75f)
            quadraticBezierTo(width * 0.7f, height * 0.72f, width * 0.8f, height)
            close()
        }
        drawPath(path = thobePath, color = Color.White)
        
        // V-neckline of Thobe
        val neckLinePath = Path().apply {
            moveTo(width * 0.44f, height * 0.75f)
            lineTo(center.x, height * 0.84f)
            lineTo(width * 0.56f, height * 0.75f)
        }
        drawPath(path = neckLinePath, color = Color.LightGray, style = Stroke(width = width * 0.015f))

        // Neck
        drawRect(
            color = skinColor,
            topLeft = Offset(width * 0.41f, height * 0.65f),
            size = Size(width * 0.18f, height * 0.12f)
        )

        // 3. Draw Face
        val faceWidth = width * 0.38f
        val faceHeight = height * 0.42f
        val faceLeft = center.x - faceWidth / 2f
        val faceTop = center.y - faceHeight / 2f - height * 0.03f

        drawOval(
            color = skinColor,
            topLeft = Offset(faceLeft, faceTop),
            size = Size(faceWidth, faceHeight)
        )

        // 4. Draw Traditional Yemeni Turban (العمامة اليمنية الشامخة)
        // Wrapped turban top band
        val turbanPath = Path().apply {
            moveTo(faceLeft - width * 0.04f, faceTop + faceHeight * 0.12f)
            quadraticBezierTo(
                center.x, faceTop - height * 0.13f,
                faceLeft + faceWidth + width * 0.04f, faceTop + faceHeight * 0.12f
            )
            quadraticBezierTo(
                center.x, faceTop + faceHeight * 0.04f,
                faceLeft - width * 0.04f, faceTop + faceHeight * 0.12f
            )
        }
        drawPath(path = turbanPath, color = turbanColor)

        // Turban wrap folds (traditional golden patterns)
        val turbanFoldPath = Path().apply {
            moveTo(faceLeft - width * 0.01f, faceTop + faceHeight * 0.06f)
            quadraticBezierTo(
                center.x, faceTop - height * 0.08f,
                faceLeft + faceWidth + width * 0.01f, faceTop + faceHeight * 0.06f
            )
        }
        drawPath(path = turbanFoldPath, color = Color(0xFFFFD700), style = Stroke(width = width * 0.012f))

        // Turban side hanging sash (شال جانبي)
        val sashPath = Path().apply {
            moveTo(faceLeft - width * 0.02f, faceTop + faceHeight * 0.1f)
            quadraticBezierTo(
                faceLeft - width * 0.08f, faceTop + faceHeight * 0.45f,
                faceLeft - width * 0.06f, height * 0.85f
            )
            lineTo(faceLeft + width * 0.01f, height * 0.85f)
            quadraticBezierTo(
                faceLeft - width * 0.01f, faceTop + faceHeight * 0.5f,
                faceLeft + width * 0.01f, faceTop + faceHeight * 0.12f
            )
            close()
        }
        drawPath(path = sashPath, color = turbanColor)

        // 5. Draw Eyes
        val eyeY = faceTop + faceHeight * 0.4f
        val leftEyeX = center.x - faceWidth * 0.24f
        val rightEyeX = center.x + faceWidth * 0.24f
        val eyeSize = faceWidth * 0.12f

        when (eyesType) {
            "wide" -> {
                // Large expressive eyes
                drawCircle(color = Color.White, radius = eyeSize * 0.8f, center = Offset(leftEyeX, eyeY))
                drawCircle(color = Color.White, radius = eyeSize * 0.8f, center = Offset(rightEyeX, eyeY))
                // Pupils
                drawCircle(color = Color(0xFF333333), radius = eyeSize * 0.4f, center = Offset(leftEyeX, eyeY))
                drawCircle(color = Color(0xFF333333), radius = eyeSize * 0.4f, center = Offset(rightEyeX, eyeY))
                // Glint
                drawCircle(color = Color.White, radius = eyeSize * 0.15f, center = Offset(leftEyeX - eyeSize * 0.15f, eyeY - eyeSize * 0.15f))
                drawCircle(color = Color.White, radius = eyeSize * 0.15f, center = Offset(rightEyeX - eyeSize * 0.15f, eyeY - eyeSize * 0.15f))
            }
            "gentle" -> {
                // Curved happy eyes
                val leftEyePath = Path().apply {
                    arcTo(Rect(leftEyeX - eyeSize, eyeY - eyeSize * 0.5f, leftEyeX + eyeSize, eyeY + eyeSize * 0.5f), 180f, 180f, false)
                }
                val rightEyePath = Path().apply {
                    arcTo(Rect(rightEyeX - eyeSize, eyeY - eyeSize * 0.5f, rightEyeX + eyeSize, eyeY + eyeSize * 0.5f), 180f, 180f, false)
                }
                drawPath(path = leftEyePath, color = Color(0xFF222222), style = Stroke(width = width * 0.015f))
                drawPath(path = rightEyePath, color = Color(0xFF222222), style = Stroke(width = width * 0.015f))
            }
            "squint" -> {
                // Serious, focused squint eyes
                drawRect(
                    color = Color(0xFF222222),
                    topLeft = Offset(leftEyeX - eyeSize * 0.8f, eyeY - eyeSize * 0.2f),
                    size = Size(eyeSize * 1.6f, eyeSize * 0.4f)
                )
                drawRect(
                    color = Color(0xFF222222),
                    topLeft = Offset(rightEyeX - eyeSize * 0.8f, eyeY - eyeSize * 0.2f),
                    size = Size(eyeSize * 1.6f, eyeSize * 0.4f)
                )
            }
        }

        // Eyebrows
        val eyebrowY = eyeY - eyeSize * 0.8f
        val eyebrowPath = Path().apply {
            // Left
            moveTo(leftEyeX - eyeSize * 1.1f, eyebrowY + eyeSize * 0.2f)
            quadraticBezierTo(leftEyeX, eyebrowY - eyeSize * 0.3f, leftEyeX + eyeSize * 0.8f, eyebrowY + eyeSize * 0.1f)
            // Right
            moveTo(rightEyeX - eyeSize * 0.8f, eyebrowY + eyeSize * 0.1f)
            quadraticBezierTo(rightEyeX, eyebrowY - eyeSize * 0.3f, rightEyeX + eyeSize * 1.1f, eyebrowY + eyeSize * 0.2f)
        }
        drawPath(path = eyebrowPath, color = Color(0xFF1E1E1E), style = Stroke(width = width * 0.012f))

        // Nose
        val nosePath = Path().apply {
            moveTo(center.x, eyeY)
            lineTo(center.x - faceWidth * 0.05f, eyeY + faceHeight * 0.15f)
            lineTo(center.x + faceWidth * 0.05f, eyeY + faceHeight * 0.15f)
        }
        drawPath(path = nosePath, color = Color.Black.copy(alpha = 0.12f))

        // 6. Draw Beard and Mustache
        val mouthY = faceTop + faceHeight * 0.72f

        when (beardStyle) {
            "yemeni_beard" -> {
                // Full elegant beard covering cheeks and chin
                val fullBeardPath = Path().apply {
                    moveTo(faceLeft + faceWidth * 0.08f, eyeY + faceHeight * 0.1f)
                    // Cheeks line down to chin
                    quadraticBezierTo(
                        faceLeft + faceWidth * 0.12f, mouthY + faceHeight * 0.15f,
                        center.x - faceWidth * 0.3f, faceTop + faceHeight + height * 0.03f
                    )
                    lineTo(center.x + faceWidth * 0.3f, faceTop + faceHeight + height * 0.03f)
                    quadraticBezierTo(
                        faceLeft + faceWidth * 0.88f, mouthY + faceHeight * 0.15f,
                        faceLeft + faceWidth * 0.92f, eyeY + faceHeight * 0.1f
                    )
                    // Inner lip line
                    quadraticBezierTo(
                        center.x, mouthY - faceHeight * 0.04f,
                        faceLeft + faceWidth * 0.08f, eyeY + faceHeight * 0.1f
                    )
                    close()
                }
                drawPath(path = fullBeardPath, color = beardColor)

                // Classic mustache overlay
                val mustachePath = Path().apply {
                    moveTo(center.x - faceWidth * 0.32f, mouthY - faceHeight * 0.05f)
                    quadraticBezierTo(center.x, mouthY - faceHeight * 0.16f, center.x + faceWidth * 0.32f, mouthY - faceHeight * 0.05f)
                    quadraticBezierTo(center.x, mouthY + faceHeight * 0.04f, center.x - faceWidth * 0.32f, mouthY - faceHeight * 0.05f)
                }
                drawPath(path = mustachePath, color = beardColor)
            }
            "mustach" -> {
                // Elegant curved mustache
                val mustachePath = Path().apply {
                    moveTo(center.x - faceWidth * 0.36f, mouthY - faceHeight * 0.04f)
                    quadraticBezierTo(center.x - faceWidth * 0.15f, mouthY - faceHeight * 0.18f, center.x, mouthY - faceHeight * 0.1f)
                    quadraticBezierTo(center.x + faceWidth * 0.15f, mouthY - faceHeight * 0.18f, center.x + faceWidth * 0.36f, mouthY - faceHeight * 0.04f)
                    quadraticBezierTo(center.x + faceWidth * 0.18f, mouthY + faceHeight * 0.08f, center.x, mouthY)
                    quadraticBezierTo(center.x - faceWidth * 0.18f, mouthY + faceHeight * 0.08f, center.x - faceWidth * 0.36f, mouthY - faceHeight * 0.04f)
                    close()
                }
                drawPath(path = mustachePath, color = beardColor)
            }
            "goatee" -> {
                // Modern goatee chin beard
                val goateePath = Path().apply {
                    moveTo(center.x - faceWidth * 0.16f, mouthY)
                    quadraticBezierTo(center.x, mouthY + faceHeight * 0.05f, center.x + faceWidth * 0.16f, mouthY)
                    lineTo(center.x + faceWidth * 0.22f, faceTop + faceHeight + height * 0.02f)
                    lineTo(center.x - faceWidth * 0.22f, faceTop + faceHeight + height * 0.02f)
                    close()
                }
                drawPath(path = goateePath, color = beardColor)

                // mustache for goatee
                val mustachePath = Path().apply {
                    moveTo(center.x - faceWidth * 0.26f, mouthY - faceHeight * 0.06f)
                    quadraticBezierTo(center.x, mouthY - faceHeight * 0.15f, center.x + faceWidth * 0.26f, mouthY - faceHeight * 0.06f)
                    quadraticBezierTo(center.x, mouthY + faceHeight * 0.02f, center.x - faceWidth * 0.26f, mouthY - faceHeight * 0.06f)
                }
                drawPath(path = mustachePath, color = beardColor)
            }
            "clean" -> {
                // Just draw a clean mouth line!
                val mouthLinePath = Path().apply {
                    moveTo(center.x - faceWidth * 0.16f, mouthY)
                    quadraticBezierTo(center.x, mouthY + faceHeight * 0.05f, center.x + faceWidth * 0.16f, mouthY)
                }
                drawPath(path = mouthLinePath, color = Color(0xFFC06060), style = Stroke(width = width * 0.012f))
            }
        }
    }
}
