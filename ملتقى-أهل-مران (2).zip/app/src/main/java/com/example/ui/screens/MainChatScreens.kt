package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Message
import com.example.data.model.User
import com.example.data.model.GroupDetail
import com.example.ui.components.CustomAvatarView
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainChatScreens(
    viewModel: ChatViewModel,
    onNavigateToProfile: (User) -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    onNavigateToGroupManagement: () -> Unit
) {
    val messages by viewModel.messages.collectAsState()
    val pinnedMsgs by viewModel.pinnedMessages.collectAsState()
    val allUsersList by viewModel.allUsers.collectAsState()
    val allGroupsList by viewModel.allGroups.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var activeMessageToReply by remember { mutableStateOf<Message?>(null) }
    var editingMessage by remember { mutableStateOf<Message?>(null) }

    // Floating panels
    var showAttachmentsSheet by remember { mutableStateOf(false) }
    var showStickersPanel by remember { mutableStateOf(false) }
    var isRecordingVoice by remember { mutableStateOf(false) }
    var recordingDuration by remember { mutableStateOf(0) }

    // Drawer state (members and chat switcher list)
    var showMembersDrawer by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val colors = MaterialTheme.colorScheme

    // Scroll to bottom when message list updates
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Voice recording simulation timer
    LaunchedEffect(isRecordingVoice) {
        if (isRecordingVoice) {
            recordingDuration = 0
            while (isRecordingVoice) {
                delay(1000)
                recordingDuration++
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { showMembersDrawer = true }
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = colors.primaryContainer,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Groups, contentDescription = null, tint = colors.onPrimaryContainer)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (viewModel.activeChatId == "main_group") viewModel.appNameState else viewModel.activeGroupDetail?.name ?: "مجموعة خاصة",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (viewModel.activeChatId == "main_group") "أعضاء الملتقى نشطون الآن" else viewModel.activeGroupDetail?.description ?: "دردشة مخصصة",
                                style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { showMembersDrawer = true }) {
                        Icon(Icons.Default.Menu, contentDescription = "قائمة الملتقى")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        // Open Search bar toggle
                        viewModel.chatSearchQuery = if (viewModel.chatSearchQuery.isEmpty()) " " else ""
                    }) {
                        Icon(Icons.Default.Search, contentDescription = "البحث")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                    // Admin badge/access inside action bar
                    if (viewModel.currentUser?.isSuperAdmin == true) {
                        FilledTonalButton(
                            onClick = onNavigateToAdmin,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = colors.tertiary.copy(alpha = 0.2f),
                                contentColor = colors.tertiary
                            ),
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("الإدارة", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.surface,
                    titleContentColor = colors.onSurface
                )
            )
        },
        bottomBar = {
            // Dynamic Composer
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(colors.surface)
                    .navigationBarsPadding()
            ) {
                // Pin list preview or reply-to indicator if active
                if (activeMessageToReply != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colors.secondaryContainer.copy(alpha = 0.3f))
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Reply, contentDescription = null, tint = colors.primary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "الرد على ${activeMessageToReply!!.senderName}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = colors.primary)
                            )
                            Text(
                                text = activeMessageToReply!!.content,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { activeMessageToReply = null }) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء الرد", modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Editing message indicator if active
                if (editingMessage != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colors.tertiaryContainer.copy(alpha = 0.3f))
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = colors.tertiary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تعديل الرسالة",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = colors.tertiary)
                            )
                            Text(
                                text = editingMessage!!.content,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = {
                            editingMessage = null
                            textInput = ""
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء التعديل", modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Interactive Sticker panel toggle row
                AnimatedVisibility(visible = showStickersPanel) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .padding(8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = colors.surfaceColorAtElevation(4.dp))
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("ملصقات ملتقى أهل مران التراثية", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val stickers = listOf(
                                    "🇾🇪" to "تحيا الجمهورية اليمنية",
                                    "☕" to "البن الخولاني الأصيل",
                                    "⚔️" to "الجنبية اليمنية العريقة",
                                    "🤝" to "ملتقى الأخوة والشهامة",
                                    "🏔️" to "جبال مران الشامخة",
                                    "🕌" to "جمعة مباركة يا رجال",
                                    "🔥" to "حيالله بفرسان صعدة"
                                )
                                stickers.forEach { (emoji, phrase) ->
                                    Card(
                                        modifier = Modifier
                                            .width(110.dp)
                                            .fillMaxHeight()
                                            .clickable {
                                                viewModel.sendMessage(
                                                    content = "$emoji $phrase",
                                                    type = "STICKER"
                                                )
                                                showStickersPanel = false
                                            },
                                        colors = CardDefaults.cardColors(containerColor = colors.background),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, colors.outlineVariant)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize(),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(emoji, fontSize = 28.sp)
                                            Text(phrase, fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Composer Form
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Attachment trigger
                    IconButton(
                        onClick = { showAttachmentsSheet = !showAttachmentsSheet },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = colors.primary)
                    ) {
                        Icon(
                            imageVector = if (showAttachmentsSheet) Icons.Default.Close else Icons.Default.Add,
                            contentDescription = "المرفقات"
                        )
                    }

                    // Sticker toggle
                    IconButton(
                        onClick = { showStickersPanel = !showStickersPanel },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = colors.primary)
                    ) {
                        Icon(Icons.Default.SentimentSatisfiedAlt, contentDescription = "الملصقات")
                    }

                    // Main Input field / Record progress bar
                    if (isRecordingVoice) {
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(23.dp),
                            colors = CardDefaults.cardColors(containerColor = colors.errorContainer)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Mic,
                                        contentDescription = null,
                                        tint = colors.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "جاري تسجيل رسالة صوتية... ${String.format("%02d:%02d", recordingDuration / 60, recordingDuration % 60)}",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = colors.onErrorContainer)
                                    )
                                }
                                TextButton(
                                    onClick = { isRecordingVoice = false },
                                    colors = ButtonDefaults.textButtonColors(contentColor = colors.error)
                                ) {
                                    Text("إلغاء")
                                }
                            }
                        }
                    } else {
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("اكتب رسالتك للملتقى...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_text_field"),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = colors.surfaceColorAtElevation(1.dp),
                                unfocusedContainerColor = colors.surfaceColorAtElevation(1.dp)
                            ),
                            trailingIcon = {
                                if (textInput.isBlank()) {
                                    IconButton(onClick = { isRecordingVoice = true }) {
                                        Icon(Icons.Default.Mic, contentDescription = "رسالة صوتية", tint = colors.onSurfaceVariant)
                                    }
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Send Button
                    IconButton(
                        onClick = {
                            if (isRecordingVoice) {
                                isRecordingVoice = false
                                viewModel.sendMessage(
                                    content = "رسالة صوتية (${recordingDuration} ثانية) 🎤",
                                    type = "AUDIO"
                                )
                            } else if (textInput.isNotBlank()) {
                                if (editingMessage != null) {
                                    viewModel.editMessage(editingMessage!!.id, textInput)
                                    editingMessage = null
                                } else {
                                    viewModel.sendMessage(
                                        content = textInput,
                                        replyToId = activeMessageToReply?.id,
                                        replyToContent = activeMessageToReply?.content
                                    )
                                    activeMessageToReply = null
                                }
                                textInput = ""
                            }
                        },
                        enabled = textInput.isNotBlank() || isRecordingVoice,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = colors.primary,
                            contentColor = colors.onPrimary
                        ),
                        modifier = Modifier
                            .size(46.dp)
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            imageVector = if (isRecordingVoice) Icons.Default.Check else Icons.AutoMirrored.Filled.Send,
                            contentDescription = "إرسال"
                        )
                    }
                }

                // Floating Attachment Options Sheet
                AnimatedVisibility(visible = showAttachmentsSheet) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = colors.surfaceColorAtElevation(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("إرفاق ملفات للملتقى", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                AttachmentOptionItem(Icons.Default.Image, "صورة", Color(0xFF4CAF50)) {
                                    viewModel.sendMessage("أرسل صورة تذكارية من طبيعة جبال مران الجميلة 🖼️", "IMAGE", "https://picsum.photos/400")
                                    showAttachmentsSheet = false
                                }
                                AttachmentOptionItem(Icons.Default.VideoLibrary, "فيديو", Color(0xFFFF9800)) {
                                    viewModel.sendMessage("أرسل مقطع مرئي للتراث اليمني والمجالس التراثية 🎥", "VIDEO", "mock_video_uri")
                                    showAttachmentsSheet = false
                                }
                                AttachmentOptionItem(Icons.Default.InsertDriveFile, "ملف", Color(0xFF2196F3)) {
                                    viewModel.sendMessage("وثيقة تاريخية.pdf 📄", "FILE", "mock_document_uri")
                                    showAttachmentsSheet = false
                                }
                                AttachmentOptionItem(Icons.Default.Place, "موقع", Color(0xFFE91E63)) {
                                    viewModel.sendMessage("موقعي الحالي: مديرية حيدان - صعدة - اليمن 📍", "LOCATION", "16.8903,43.4320")
                                    showAttachmentsSheet = false
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(colors.surfaceColorAtElevation(1.dp))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Search result bar if query active
                if (viewModel.chatSearchQuery.isNotBlank()) {
                    OutlinedTextField(
                        value = viewModel.chatSearchQuery,
                        onValueChange = { viewModel.chatSearchQuery = it },
                        placeholder = { Text("ابحث في رسائل المحادثة...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { viewModel.chatSearchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = null)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                // Pinned Messages Banner
                val currentPinned = pinnedMsgs
                if (currentPinned.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colors.primaryContainer.copy(alpha = 0.8f))
                            .clickable {
                                // Scroll to pinned message
                                val idx = messages.indexOfFirst { it.id == currentPinned.first().id }
                                if (idx != -1) {
                                    scope.launch { listState.animateScrollToItem(idx) }
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PushPin, contentDescription = null, tint = colors.onPrimaryContainer, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📌 الرسالة المثبتة: ${currentPinned.first().content}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = colors.onPrimaryContainer),
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        IconButton(
                            onClick = { viewModel.togglePinMessage(currentPinned.first().id) },
                            modifier = Modifier.size(18.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = colors.onPrimaryContainer, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                // Chat Messages List
                val filteredMessages = if (viewModel.chatSearchQuery.isNotBlank() && viewModel.chatSearchQuery != " ") {
                    messages.filter { it.content.contains(viewModel.chatSearchQuery, ignoreCase = true) }
                } else {
                    messages
                }

                if (filteredMessages.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.Forum,
                            contentDescription = null,
                            tint = colors.primary.copy(alpha = 0.3f),
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد رسائل حالياً في الغرفة.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = colors.onSurface.copy(alpha = 0.4f)),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredMessages) { message ->
                            MessageBubble(
                                message = message,
                                isMe = message.senderId == viewModel.currentUser?.id,
                                colors = colors,
                                viewModel = viewModel,
                                onReply = { activeMessageToReply = message },
                                onEdit = {
                                    editingMessage = message
                                    textInput = message.content
                                },
                                onProfileClick = {
                                    val userObj = allUsersList.find { it.id == message.senderId }
                                    if (userObj != null) onNavigateToProfile(userObj)
                                }
                            )
                        }
                    }
                }
            }

            // Slide out Drawer Overlay for Forum Members and Rooms
            if (showMembersDrawer) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable { showMembersDrawer = false }
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.82f)
                            .align(Alignment.CenterStart)
                            .clickable(enabled = false, onClick = {}),
                        color = colors.surface,
                        tonalElevation = 8.dp
                    ) {
                        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                            // Header
                            Text(
                                text = "مجلس ملتقى أهل مران",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = colors.primary)
                            )
                            Text(
                                text = "الحاضرون والمنضمون للملتقى العام",
                                style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)),
                                modifier = Modifier.padding(bottom = 16.dp)
                            )

                            // Group Selection Tab Row
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("المجموعات المتاحة", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                IconButton(onClick = onNavigateToGroupManagement) {
                                    Icon(Icons.Default.GroupAdd, contentDescription = "إنشاء مجموعة", tint = colors.primary)
                                }
                            }

                            // Dynamic list of groups
                            Card(
                                modifier = Modifier.fillMaxWidth().heightIn(max = 100.dp),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, colors.outlineVariant)
                            ) {
                                LazyColumn {
                                    item {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.setChatId("main_group")
                                                    showMembersDrawer = false
                                                }
                                                .background(if (viewModel.activeChatId == "main_group") colors.primary.copy(alpha = 0.15f) else Color.Transparent)
                                                .padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Forum, contentDescription = null, tint = colors.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("ملتقى أهل مران العام", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                        }
                                    }
                                    items(allGroupsList) { gp ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    viewModel.setChatId("group_${gp.id}", groupDetail = gp)
                                                    showMembersDrawer = false
                                                }
                                                .background(if (viewModel.activeChatId == "group_${gp.id}") colors.primary.copy(alpha = 0.15f) else Color.Transparent)
                                                .padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Groups, contentDescription = null, tint = colors.secondary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(gp.name, style = MaterialTheme.typography.bodyMedium)
                                        }
                                    }
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 12.dp))

                            Text(
                                "الأعضاء المتصلون بالإنترنت (${allUsersList.filter { it.status == "متصل" }.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(bottom = 10.dp)
                            )

                            // List of members
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(allUsersList) { user ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                showMembersDrawer = false
                                                onNavigateToProfile(user)
                                            }
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box {
                                            CustomAvatarView(
                                                modifier = Modifier.size(40.dp),
                                                skinColorHex = if (user.avatarUrl.startsWith("#")) user.avatarUrl else "#D2B48C"
                                            )
                                            // status dot
                                            Box(
                                                modifier = Modifier
                                                    .size(11.dp)
                                                    .align(Alignment.BottomEnd)
                                                    .background(
                                                        color = when (user.status) {
                                                            "متصل" -> Color.Green
                                                            "مشغول" -> Color.Yellow
                                                            else -> Color.Gray
                                                        },
                                                        shape = CircleShape
                                                    )
                                                    .border(1.5.dp, colors.surface, CircleShape)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = user.name,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = user.status,
                                                style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f))
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AttachmentOptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Surface(
            shape = CircleShape,
            color = tint.copy(alpha = 0.15f),
            modifier = Modifier.size(50.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: Message,
    isMe: Boolean,
    colors: ColorScheme,
    viewModel: ChatViewModel,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onProfileClick: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isMe) {
            Box(modifier = Modifier.clickable { onProfileClick() }) {
                CustomAvatarView(
                    modifier = Modifier.size(36.dp),
                    skinColorHex = if (message.senderAvatar.startsWith("#")) message.senderAvatar else "#D2B48C"
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isMe) Alignment.End else Alignment.Start,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            // Sender name (only for other users in group chats)
            if (!isMe) {
                Text(
                    text = message.senderName,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = colors.primary),
                    modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
                )
            }

            // Message Body Card
            Card(
                shape = RoundedCornerShape(
                    topStart = if (isMe) 16.dp else 4.dp,
                    topEnd = if (isMe) 4.dp else 16.dp,
                    bottomStart = 16.dp,
                    bottomEnd = 16.dp
                ),
                colors = CardDefaults.cardColors(
                    containerColor = if (isMe) colors.primary else colors.surfaceVariant
                ),
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .combinedClickable(
                        onLongClick = { showMenu = true },
                        onClick = {}
                    )
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    // Reply preview context
                    if (message.replyToContent != null) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isMe) colors.primaryContainer.copy(alpha = 0.3f) else colors.background.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = message.replyToContent,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(6.dp)
                            )
                        }
                    }

                    // Content based on message type
                    when (message.messageType) {
                        "STICKER" -> {
                            Text(
                                text = message.content,
                                fontSize = 32.sp,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            )
                        }
                        "IMAGE" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.DarkGray)
                            ) {
                                // Fallback layout representation of the photo
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.Photo, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(40.dp))
                                    Text("صورة من أهل مران", color = Color.White, fontSize = 10.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyMedium.copy(color = if (isMe) colors.onPrimary else colors.onSurfaceVariant)
                            )
                        }
                        "VIDEO" -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .align(Alignment.Center)
                                        .background(colors.primary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyMedium.copy(color = if (isMe) colors.onPrimary else colors.onSurfaceVariant)
                            )
                        }
                        "AUDIO" -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = if (isMe) colors.onPrimary else colors.primary)
                                Spacer(modifier = Modifier.width(6.dp))
                                // Waveform lines representation
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    val bars = listOf(10, 15, 25, 12, 18, 8, 20, 14, 5, 15)
                                    bars.forEach { h ->
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(h.dp)
                                                .background(if (isMe) colors.onPrimary else colors.primary)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = message.content,
                                    fontSize = 11.sp,
                                    color = if (isMe) colors.onPrimary else colors.onSurfaceVariant
                                )
                            }
                        }
                        "LOCATION" -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE3F2FD))
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Map, contentDescription = null, tint = Color(0xFF1976D2))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("خريطة الموقع الجغرافي النشط", color = Color(0xFF1976D2), fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyMedium.copy(color = if (isMe) colors.onPrimary else colors.onSurfaceVariant)
                            )
                        }
                        else -> {
                            // TEXT or fallback
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyMedium.copy(color = if (isMe) colors.onPrimary else colors.onSurfaceVariant)
                            )
                        }
                    }

                    // Bottom info (edited tag, time, pin status, reactions)
                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (message.isEdited) {
                            Text(
                                "معدلة",
                                fontSize = 8.sp,
                                color = (if (isMe) colors.onPrimary else colors.onSurfaceVariant).copy(alpha = 0.5f),
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                        if (message.isPinned) {
                            Icon(
                                Icons.Default.PushPin,
                                contentDescription = null,
                                tint = (if (isMe) colors.onPrimary else colors.onSurfaceVariant).copy(alpha = 0.6f),
                                modifier = Modifier
                                    .size(10.dp)
                                    .padding(end = 4.dp)
                            )
                        }
                        Text(
                            text = android.text.format.DateFormat.format("hh:mm a", message.timestamp).toString(),
                            fontSize = 8.sp,
                            color = (if (isMe) colors.onPrimary else colors.onSurfaceVariant).copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // Reaction badges row
            if (message.reactions.isNotBlank()) {
                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    message.reactions.split(",").distinct().forEach { reaction ->
                        Surface(
                            shape = CircleShape,
                            color = colors.surfaceColorAtElevation(3.dp),
                            border = BorderStroke(0.5.dp, colors.outlineVariant),
                            modifier = Modifier.clickable { viewModel.addReaction(message.id, reaction) }
                        ) {
                            Text(reaction, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp)
                        }
                    }
                }
            }

            // Quick emoji picker context menu
            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val emojis = listOf("👍", "❤️", "😂", "😮", "😢", "🔥")
                    emojis.forEach { emoji ->
                        Text(
                            text = emoji,
                            fontSize = 20.sp,
                            modifier = Modifier
                                .clickable {
                                    viewModel.addReaction(message.id, emoji)
                                    showMenu = false
                                }
                                .padding(4.dp)
                        )
                    }
                }
                Divider()
                DropdownMenuItem(
                    text = { Text("رد") },
                    leadingIcon = { Icon(Icons.Default.Reply, contentDescription = null) },
                    onClick = {
                        onReply()
                        showMenu = false
                    }
                )
                if (isMe) {
                    DropdownMenuItem(
                        text = { Text("تعديل") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        onClick = {
                            onEdit()
                            showMenu = false
                        }
                    )
                }
                DropdownMenuItem(
                    text = { Text("تثبيت الرسالة") },
                    leadingIcon = { Icon(Icons.Default.PushPin, contentDescription = null) },
                    onClick = {
                        viewModel.togglePinMessage(message.id)
                        showMenu = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("حذف للجميع") },
                    leadingIcon = { Icon(Icons.Default.DeleteForever, contentDescription = null) },
                    onClick = {
                        viewModel.deleteMessageForAll(message.id)
                        showMenu = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("حذف محلي") },
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                    onClick = {
                        viewModel.deleteMessageLocal(message.id)
                        showMenu = false
                    }
                )
            }
        }
    }
}
