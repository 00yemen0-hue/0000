package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var showSoundDialog by remember { mutableStateOf(false) }
    var blockList by remember { mutableStateOf(listOf("صالح المعتدي", "حساب مشبوه 99")) }

    val syncState by viewModel.supabaseService.syncState.collectAsState()
    val isConfigured = viewModel.supabaseService.isConfigured
    val coroutineScope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    var showSqlDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إعدادات التطبيق العامة", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(colors.surfaceColorAtElevation(1.dp))
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("المظهر واللغة", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))

            // Dark Mode Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DarkMode, contentDescription = null, tint = colors.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("الوضع الليلي الفخم", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("مناسب للرؤية الليلية والحفاظ على شحن البطارية", fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.5f))
                        }
                    }
                    Switch(
                        checked = viewModel.isDarkMode,
                        onCheckedChange = { viewModel.isDarkMode = it },
                        modifier = Modifier.testTag("dark_mode_switch")
                    )
                }
            }

            // Language Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = colors.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("لغة التطبيق", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("العربية هي اللغة الافتراضية للملتقى", fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.5f))
                        }
                    }
                    TextButton(onClick = {
                        viewModel.currentLanguage = if (viewModel.currentLanguage == "ar") "en" else "ar"
                    }) {
                        Text(if (viewModel.currentLanguage == "ar") "العربية (تغيير)" else "English (Change)")
                    }
                }
            }

            Text("الإشعارات والمكالمات", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))

            // Sound picker Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showSoundDialog = true }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = colors.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("نغمة الإشعارات والتنبيهات", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("النغمة النشطة: ${viewModel.notificationSound}", fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.5f))
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }

            Text("الخصوصية والأمان والمستخدمين", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))

            // Block List Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Block, contentDescription = null, tint = colors.error)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("قائمة المستخدمين المحظورين", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    if (blockList.isEmpty()) {
                        Text("لا يوجد مستخدمون في قائمة الحظر حالياً.", fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.4f))
                    } else {
                        blockList.forEach { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(user, style = MaterialTheme.typography.bodySmall)
                                TextButton(
                                    onClick = { blockList = blockList.filter { it != user } },
                                    colors = ButtonDefaults.textButtonColors(contentColor = colors.primary)
                                ) {
                                    Text("إلغاء الحظر", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Devices Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Devices, contentDescription = null, tint = colors.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("إدارة الأجهزة المتصلة", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• جهاز الأندرويد الحالي (نشط الآن)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.primary)
                    Text("• متصفح الويب - صنعاء، اليمن (قبل يومين)", fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.5f))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Supabase Sync Management section
            Text("قاعدة بيانات Supabase السحابية", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CloudQueue,
                                contentDescription = null,
                                tint = if (isConfigured) colors.primary else colors.onSurface.copy(alpha = 0.4f)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("المزامنة السحابية الفورية", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                Text(
                                    text = if (isConfigured) "متصل بـ Supabase بنجاح" else "غير متصل (الوضع المحلي فقط)",
                                    fontSize = 11.sp,
                                    color = if (isConfigured) colors.primary else colors.onSurface.copy(alpha = 0.5f)
                                )
                            }
                        }
                        
                        if (isConfigured) {
                            var isSyncInProgress by remember { mutableStateOf(false) }
                            Button(
                                onClick = {
                                    isSyncInProgress = true
                                    coroutineScope.launch {
                                        viewModel.supabaseService.syncAll()
                                        isSyncInProgress = false
                                    }
                                },
                                enabled = !isSyncInProgress,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = colors.primaryContainer, contentColor = colors.onPrimaryContainer)
                            ) {
                                if (isSyncInProgress) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = colors.onPrimaryContainer)
                                } else {
                                    Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("مزامنة الآن", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Sync state log feedback
                    when (val state = syncState) {
                        is com.example.data.supabase.SyncState.Syncing -> {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(state.message, style = MaterialTheme.typography.bodySmall.copy(color = colors.primary))
                            }
                        }
                        is com.example.data.supabase.SyncState.Success -> {
                            Text("✓ تمت مزامنة كافة البيانات والرسائل بنجاح مع Supabase.", style = MaterialTheme.typography.bodySmall.copy(color = colors.primary))
                        }
                        is com.example.data.supabase.SyncState.Error -> {
                            Text(state.error, style = MaterialTheme.typography.bodySmall.copy(color = colors.error))
                        }
                        else -> {
                            if (isConfigured) {
                                Text("المزامنة السحابية نشطة وتلقائية عند إرسال رسالة أو تحديث حسابك.", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurfaceVariant))
                            } else {
                                Text("لم تتم المزامنة. أدخل SUPABASE_URL و SUPABASE_ANON_KEY في Secrets panel في لوحة تحكم AI Studio لتفعيل الحفظ والنسخ الفوري للملتقى.", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.6f)))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showSqlDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, colors.outline.copy(alpha = 0.3f))
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("عرض وتعليمات كود SQL لبناء جداول Supabase", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Logout Button
            Button(
                onClick = { viewModel.logoutUser() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = colors.error),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تسجيل الخروج الآمن من الملتقى")
            }
        }
    }

    // SQL Dialog Helper Block
    if (showSqlDialog) {
        AlertDialog(
            onDismissRequest = { showSqlDialog = false },
            title = { Text("إعداد جداول Supabase (SQL)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "انسخ الكود أدناه والصقه في SQL Editor بمشروعك في Supabase لتهيئة الجداول والمزامنة الأخوية الفورية:",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .background(colors.surfaceVariant, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        val sqlText = com.example.data.supabase.SupabaseService.getDatabaseSchemaSQL()
                        SelectionContainer {
                            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                                Text(
                                    text = sqlText,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = colors.onSurfaceVariant
                                )
                            }
                        }
                    }
                    
                    Button(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(com.example.data.supabase.SupabaseService.getDatabaseSchemaSQL()))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.secondaryContainer, contentColor = colors.onSecondaryContainer)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("نسخ كود SQL بالكامل", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSqlDialog = false }) { Text("إغلاق") }
            }
        )
    }

    // Alert Sound Dialog Selector
    if (showSoundDialog) {
        AlertDialog(
            onDismissRequest = { showSoundDialog = false },
            title = { Text("اختر نغمة التنبيهات المفضلة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val sounds = listOf("الافتراضية المارانية 🔔", "هدير السيول في صعدة 🌊", "شدو بلابل الجبال 🐦", "رنين الجنبية الفخر ⚔️", "صامت 🔕")
                    sounds.forEach { snd ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.notificationSound = snd
                                    showSoundDialog = false
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = viewModel.notificationSound == snd, onClick = {
                                viewModel.notificationSound = snd
                                showSoundDialog = false
                            })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(snd)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSoundDialog = false }) { Text("إغلاق") }
            }
        )
    }
}
