package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MaranGold
import com.example.ui.theme.YemeniGreenPrimary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun YemeniEmblem(
    modifier: Modifier = Modifier,
    primaryColor: Color = YemeniGreenPrimary,
    goldColor: Color = MaranGold,
    style: String = "emblem_heritage" // emblem_heritage, emblem_classic, emblem_modern
) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val width = size.width
        val height = size.height
        val center = Offset(width / 2f, height / 2f)
        val radius = width * 0.45f

        // 1. Draw outer heritage gold border
        drawCircle(
            color = goldColor,
            radius = radius,
            center = center,
            style = Stroke(width = width * 0.03f)
        )

        // Draw geometric triangle patterns around the border (traditional Yemeni architecture)
        if (style == "emblem_heritage" || style == "emblem_classic") {
            val numTriangles = 32
            val triangleSize = radius * 0.08f
            for (i in 0 until numTriangles) {
                val angle = (i * (360f / numTriangles)) * (Math.PI.toFloat() / 180f)
                val px = center.x + (radius - triangleSize) * cos(angle)
                val py = center.y + (radius - triangleSize) * sin(angle)

                val path = Path().apply {
                    moveTo(px, py)
                    lineTo(
                        px + triangleSize * cos(angle + 0.5f),
                        py + triangleSize * sin(angle + 0.5f)
                    )
                    lineTo(
                        px + triangleSize * cos(angle - 0.5f),
                        py + triangleSize * sin(angle - 0.5f)
                    )
                    close()
                }
                drawPath(path = path, color = goldColor)
            }
        }

        // 2. Draw inner emerald circle fill
        drawCircle(
            color = primaryColor.copy(alpha = 0.15f),
            radius = radius * 0.88f,
            center = center
        )

        // 3. Draw Yemeni Jambiya (Dagger) / coffee twigs in the center
        // T-shaped Jambiya handle
        val handleWidth = width * 0.14f
        val handleHeight = height * 0.16f
        val topY = height * 0.28f

        // T-top bar
        drawRect(
            color = goldColor,
            topLeft = Offset(center.x - handleWidth, topY),
            size = Size(handleWidth * 2f, handleHeight * 0.25f)
        )
        // Handle core
        drawRect(
            color = goldColor,
            topLeft = Offset(center.x - handleWidth * 0.35f, topY + handleHeight * 0.2f),
            size = Size(handleWidth * 0.7f, handleHeight * 0.8f)
        )

        // Curved jambiya blade
        val bladePath = Path().apply {
            moveTo(center.x - handleWidth * 0.3f, topY + handleHeight)
            lineTo(center.x + handleWidth * 0.3f, topY + handleHeight)
            // Curve down left
            quadraticBezierTo(
                center.x + handleWidth * 0.4f, height * 0.62f,
                center.x - handleWidth * 1.1f, height * 0.68f // curved tip
            )
            // Curving back to center
            quadraticBezierTo(
                center.x - handleWidth * 0.2f, height * 0.58f,
                center.x - handleWidth * 0.3f, topY + handleHeight
            )
            close()
        }
        drawPath(path = bladePath, color = goldColor)

        // Jambiya central silver-gold rib line
        val ribPath = Path().apply {
            moveTo(center.x, topY + handleHeight)
            quadraticBezierTo(
                center.x + handleWidth * 0.1f, height * 0.58f,
                center.x - handleWidth * 0.9f, height * 0.65f
            )
        }
        drawPath(path = ribPath, color = primaryColor, style = Stroke(width = width * 0.015f))

        // 4. Coffee Branches (سنابل البن أو القمح) flanking the jambiya
        if (style != "emblem_modern") {
            val leafRadius = radius * 0.45f
            for (side in listOf(-1, 1)) {
                for (j in 0..4) {
                    val angleOffset = side * (35f + j * 20f)
                    val angle = (90f + angleOffset) * (Math.PI.toFloat() / 180f)
                    val leafX = center.x + leafRadius * sin(angle)
                    val leafY = center.y + leafRadius * cos(angle)

                    drawCircle(
                        color = goldColor.copy(alpha = 0.8f),
                        radius = width * 0.025f,
                        center = Offset(leafX, leafY)
                    )
                }
            }
        }
    }
}
