package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.components.CustomAvatarView
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun ParsedUserAvatar(user: User, modifier: Modifier = Modifier) {
    if (user.avatarUrl.contains("|")) {
        val parts = user.avatarUrl.split("|")
        if (parts.size >= 6) {
            CustomAvatarView(
                modifier = modifier,
                skinColorHex = parts[0],
                eyesType = parts[1],
                beardStyle = parts[2],
                beardColorHex = parts[3],
                turbanColorHex = parts[4],
                bgColorHex = parts[5]
            )
            return
        }
    }
    // Fallback
    CustomAvatarView(
        modifier = modifier,
        skinColorHex = if (user.avatarUrl.startsWith("#")) user.avatarUrl else "#D2B48C",
        eyesType = "wide",
        beardStyle = if (user.isSuperAdmin) "yemeni_beard" else "clean",
        turbanColorHex = if (user.isSuperAdmin) "#800000" else "#555555"
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ChatViewModel,
    profileUser: User,
    onBack: () -> Unit,
    onStartPrivateChat: (User) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val isMe = profileUser.id == viewModel.currentUser?.id

    // Edit states
    var editMode by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(profileUser.name) }
    var bioInput by remember { mutableStateOf(profileUser.bio) }
    var statusInput by remember { mutableStateOf(profileUser.status) }
    var emailInput by remember { mutableStateOf(profileUser.email) }

    // Avatar Creator board states
    var showAvatarCreator by remember { mutableStateOf(false) }
    var tempSkinColor by remember { mutableStateOf(viewModel.avatarSkinColor) }
    var tempEyesType by remember { mutableStateOf(viewModel.avatarEyesType) }
    var tempBeardStyle by remember { mutableStateOf(viewModel.avatarBeardStyle) }
    var tempBeardColor by remember { mutableStateOf(viewModel.avatarBeardColor) }
    var tempTurbanColor by remember { mutableStateOf(viewModel.avatarTurbanColor) }
    var tempBgColor by remember { mutableStateOf(viewModel.avatarBgColor) }

    // Report dialog
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isMe) "ملفي الشخصي" else "عرض العضوية", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(colors.surfaceColorAtElevation(1.dp))
                .verticalScroll(rememberScrollState())
        ) {
            // 1. Cover Photo Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(colors.primary)
            ) {
                // Diagonal architectural lines in backdrop
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.1f),
                        start = androidx.compose.ui.geometry.Offset(0f, 0f),
                        end = androidx.compose.ui.geometry.Offset(size.width, size.height),
                        strokeWidth = 10f
                    )
                }
            }

            // 2. Avatar & Name card overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-50).dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    border = BorderStroke(4.dp, colors.surface),
                    modifier = Modifier.size(110.dp),
                    shadowElevation = 4.dp
                ) {
                    ParsedUserAvatar(user = profileUser, modifier = Modifier.fillMaxSize())
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = profileUser.name,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = colors.onSurface)
                )
                Text(
                    text = if (profileUser.isSuperAdmin) "المشرف العام (Super Admin)" else "عضو ملتقى مران",
                    style = MaterialTheme.typography.bodySmall.copy(color = colors.primary, fontWeight = FontWeight.Bold)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = when (profileUser.status) {
                                    "متصل" -> Color.Green
                                    "مشغول" -> Color.Yellow
                                    else -> Color.Gray
                                },
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        profileUser.status,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            // 3. Main Actions / Fields
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-30).dp)
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (isMe) {
                    if (!editMode && !showAvatarCreator) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { editMode = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تعديل البيانات")
                            }

                            Button(
                                onClick = { showAvatarCreator = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = colors.secondary)
                            ) {
                                Icon(Icons.Default.Face, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("صانع الرمزيات")
                            }
                        }
                    }
                } else {
                    // Chat triggers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onStartPrivateChat(profileUser) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("بدء دردشة خاصة")
                        }

                        Button(
                            onClick = { showReportDialog = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = colors.errorContainer, contentColor = colors.onErrorContainer)
                        ) {
                            Icon(Icons.Default.Report, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إبلاغ عن مخالفة")
                        }
                    }
                }

                // Edit Mode Board
                if (editMode) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = colors.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("تحديث البيانات الشخصية", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))

                            OutlinedTextField(
                                value = nameInput,
                                onValueChange = { nameInput = it },
                                label = { Text("الاسم") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            OutlinedTextField(
                                value = bioInput,
                                onValueChange = { bioInput = it },
                                label = { Text("النبذة التعريفية") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            // Status drop down selection representation
                            Text("الحالة النشطة:", fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf("متصل", "مشغول", "غير متصل").forEach { st ->
                                    FilterChip(
                                        selected = statusInput == st,
                                        onClick = { statusInput = st },
                                        label = { Text(st) }
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { editMode = false }) { Text("إلغاء") }
                                Button(onClick = {
                                    viewModel.updateProfile(nameInput, emailInput, bioInput, statusInput)
                                    editMode = false
                                }) {
                                    Text("حفظ")
                                }
                            }
                        }
                    }
                }

                // Dynamic Inside-App Avatar Creator System Board (100% complete design)
                if (showAvatarCreator) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = colors.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                "صانع الرمزيات والعمائم اليمنية التراثية",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = colors.primary)
                            )

                            // Live preview of the constructed avatar
                            Box(
                                modifier = Modifier
                                    .size(130.dp)
                                    .align(Alignment.CenterHorizontally)
                                    .clip(CircleShape)
                                    .border(2.dp, colors.primary, CircleShape)
                            ) {
                                CustomAvatarView(
                                    modifier = Modifier.fillMaxSize(),
                                    skinColorHex = tempSkinColor,
                                    eyesType = tempEyesType,
                                    beardStyle = tempBeardStyle,
                                    beardColorHex = tempBeardColor,
                                    turbanColorHex = tempTurbanColor,
                                    bgColorHex = tempBgColor
                                )
                            }

                            // Skin selector
                            Text("لون البشرة المفضل:", fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("#D2B48C" to "حنطي", "#E6C2A0" to "فاتح", "#C68E62" to "قمحي", "#8D5524" to "أسمر").forEach { (hex, label) ->
                                    FilterChip(
                                        selected = tempSkinColor == hex,
                                        onClick = { tempSkinColor = hex },
                                        label = { Text(label, fontSize = 10.sp) }
                                    )
                                }
                            }

                            // Eyes selector
                            Text("رسمة العينين:", fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("wide" to "واسعة", "gentle" to "وديعة", "squint" to "حادة").forEach { (type, label) ->
                                    FilterChip(
                                        selected = tempEyesType == type,
                                        onClick = { tempEyesType = type },
                                        label = { Text(label, fontSize = 10.sp) }
                                    )
                                }
                            }

                            // Beard style selector
                            Text("نمط الشارب واللحية المارانية الأصيلة:", fontSize = 12.sp)
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("yemeni_beard" to "لحية يمنية كاملة", "mustach" to "شنب عريض", "goatee" to "سكسوكة", "clean" to "حليق").forEach { (style, label) ->
                                    FilterChip(
                                        selected = tempBeardStyle == style,
                                        onClick = { tempBeardStyle = style },
                                        label = { Text(label, fontSize = 10.sp) }
                                    )
                                }
                            }

                            // Turban Headwear Color
                            Text("لون العمامة والشال اليماني الشامخ:", fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("#800000" to "عنابي", "#FFFFFF" to "أبيض ناصع", "#006400" to "أخضر داكن", "#4A3728" to "بني عتيق").forEach { (hex, label) ->
                                    FilterChip(
                                        selected = tempTurbanColor == hex,
                                        onClick = { tempTurbanColor = hex },
                                        label = { Text(label, fontSize = 10.sp) }
                                    )
                                }
                            }

                            // Background color
                            Text("لون الخلفية الرمزية:", fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("#0A5C36" to "أخضر عقيق", "#104E8B" to "أزرق", "#333333" to "فحمي", "#B8860B" to "ذهبي").forEach { (hex, label) ->
                                    FilterChip(
                                        selected = tempBgColor == hex,
                                        onClick = { tempBgColor = hex },
                                        label = { Text(label, fontSize = 10.sp) }
                                    )
                                }
                            }

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { showAvatarCreator = false }) { Text("إلغاء") }
                                Button(onClick = {
                                    viewModel.avatarSkinColor = tempSkinColor
                                    viewModel.avatarEyesType = tempEyesType
                                    viewModel.avatarBeardStyle = tempBeardStyle
                                    viewModel.avatarBeardColor = tempBeardColor
                                    viewModel.avatarTurbanColor = tempTurbanColor
                                    viewModel.avatarBgColor = tempBgColor

                                    // Serialize and save to user's database entry
                                    val serializedStr = "$tempSkinColor|$tempEyesType|$tempBeardStyle|$tempBeardColor|$tempTurbanColor|$tempBgColor"
                                    viewModel.saveCustomAvatar(serializedStr)
                                    showAvatarCreator = false
                                }) {
                                    Text("حفظ الصورة وتعديل ملفي شخصياً")
                                }
                            }
                        }
                    }
                }

                // General Bio & Details Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = colors.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("النبذة التعريفية والأثر", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))
                        Text(profileUser.bio, style = MaterialTheme.typography.bodyMedium)
                        Divider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Email, contentDescription = null, tint = colors.primary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(profileUser.email, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    // Report Dialog
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("تقديم بلاغ إداري ضد العضو") },
            text = {
                Column {
                    Text("يرجى توضيح سبب المخالفة بدقة لمراجعتها من قبل الإدارة العامة للملتقى:")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        placeholder = { Text("سبب الإساءة أو الإزعاج...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reportReason.isNotBlank()) {
                            viewModel.fileReport(profileUser.name, reportReason)
                            showReportDialog = false
                            reportReason = ""
                        }
                    }
                ) {
                    Text("رفع البلاغ للإدارة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
