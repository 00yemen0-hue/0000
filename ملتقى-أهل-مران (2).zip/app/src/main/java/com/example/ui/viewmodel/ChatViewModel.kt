package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.database.AppDatabase
import com.example.data.repository.ChatRepository
import com.example.data.model.*
import com.example.data.supabase.SupabaseService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val database: AppDatabase = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "maran_chat_v1.db"
    ).fallbackToDestructiveMigration().build()

    val repository = ChatRepository(database.chatDao())
    val supabaseService = SupabaseService(repository)

    // --- Core UI State ---
    var currentUser by mutableStateOf<User?>(null)
        private set

    var activeChatId by mutableStateOf("main_group")
        private set

    var activePrivateUser by mutableStateOf<User?>(null)
        private set

    var activeGroupDetail by mutableStateOf<GroupDetail?>(null)
        private set

    var isDarkMode by mutableStateOf(true)
    var currentLanguage by mutableStateOf("ar") // "ar" / "en"
    var notificationSound by mutableStateOf("الافتراضية") // Default sound

    // Dynamic App branding (Admin configurable)
    var appNameState by mutableStateOf("ملتقى أهل مران")
    var appLogoState by mutableStateOf("emblem_heritage") // emblem_heritage, emblem_classic, emblem_modern

    // Call Simulation State
    var isCallActive by mutableStateOf(false)
    var activeCallType by mutableStateOf<String?>(null) // "AUDIO" / "VIDEO"
    var activeCallUser by mutableStateOf<User?>(null)
    var callDuration by mutableStateOf(0)
    var isCallMuted by mutableStateOf(false)
    var isCallVideoPaused by mutableStateOf(false)
    private var callJob: Job? = null

    // Search Query
    var chatSearchQuery by mutableStateOf("")

    // Admin state
    var selectedUserForAdminEdit by mutableStateOf<User?>(null)
    var selectedGroupForAdminEdit by mutableStateOf<GroupDetail?>(null)

    // Flows from Repository
    val allUsers: StateFlow<List<User>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGroups: StateFlow<List<GroupDetail>> = repository.allGroups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminLogs: StateFlow<List<AdminLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<Report>> = repository.allReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reactive messages based on activeChatId
    private val _activeChatIdFlow = MutableStateFlow("main_group")
    val messages: StateFlow<List<Message>> = _activeChatIdFlow
        .flatMapLatest { chatId -> repository.getMessagesForChat(chatId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pinnedMessages: StateFlow<List<Message>> = _activeChatIdFlow
        .flatMapLatest { chatId -> repository.getPinnedMessagesForChat(chatId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Avatar Creator State
    var avatarSkinColor by mutableStateOf("#D2B48C") // Beige
    var avatarEyesType by mutableStateOf("wide") // wide, gentle, squint
    var avatarBeardStyle by mutableStateOf("yemeni_beard") // yemeni_beard, mustach, clean, goatee
    var avatarBeardColor by mutableStateOf("#4A3728")
    var avatarTurbanColor by mutableStateOf("#800000") // Red/Burgundy Turban
    var avatarBgColor by mutableStateOf("#0A5C36") // Emerald green background

    init {
        // Seeding database on startup if empty
        viewModelScope.launch {
            delay(100) // Small breathing space
            seedDatabaseIfNeeded()
            if (supabaseService.isConfigured) {
                supabaseService.syncAll()
            }
            simulatePeriodicIncomingMessages()
        }
    }

    fun setChatId(chatId: String, privateUser: User? = null, groupDetail: GroupDetail? = null) {
        activeChatId = chatId
        activePrivateUser = privateUser
        activeGroupDetail = groupDetail
        _activeChatIdFlow.value = chatId
    }

    private suspend fun seedDatabaseIfNeeded() {
        val users = repository.allUsers.first()
        if (users.isEmpty()) {
            // 1. Create default Super Admin (customizable dynamically)
            val superAdmin = User(
                email = "admin@maran.com",
                password = "admin", // Secure fallback, can change securely in App Settings
                name = "المشرف العام (أبو مران)",
                avatarUrl = "avatar_admin",
                bio = "المدير المسؤول عن ملتقى أهل مران العام. أهلاً ومرحباً بالجميع.",
                status = "متصل",
                isSuperAdmin = true
            )
            repository.insertUser(superAdmin)

            // 2. Create community members
            val saleh = User(
                email = "saleh@maran.com",
                password = "123",
                name = "صالح المراني",
                avatarUrl = "avatar_2",
                bio = "سفير التراث اليمني الأصيل 🇾🇪 مران العز والفخر",
                status = "متصل"
            )
            val hamdan = User(
                email = "hamdan@maran.com",
                password = "123",
                name = "أبو همدان",
                avatarUrl = "avatar_3",
                bio = "مهتم بالقهوة اليمنية العريقة ومزارع صعدة الخيرة ☕",
                status = "متصل"
            )
            val belqis = User(
                email = "belqis@maran.com",
                password = "123",
                name = "بلقيس الهمداني",
                avatarUrl = "avatar_4",
                bio = "شاعرة وكاتبة يمنية مهتمة بالتاريخ والموروث الشعبي",
                status = "مشغول"
            )
            val nasim = User(
                email = "nasim@maran.com",
                password = "123",
                name = "نسيم الخولاني",
                avatarUrl = "avatar_5",
                bio = "نسيم الصباح من قمم جبال مران الشامخة 🏔️",
                status = "غير متصل"
            )

            val salehId = repository.insertUser(saleh).toInt()
            val hamdanId = repository.insertUser(hamdan).toInt()
            val belqisId = repository.insertUser(belqis).toInt()
            val nasimId = repository.insertUser(nasim).toInt()

            // 3. Create Main Forum Group
            val mainGroup = GroupDetail(
                name = "ملتقى أهل مران",
                description = "المجلس العام والمجلس الأخوي الرئيسي لأهل مران الأحرار والمحبين في كل مكان",
                iconUrl = "group_main",
                adminIds = "1",
                memberIds = "1,$salehId,$hamdanId,$belqisId,$nasimId"
            )
            repository.insertGroup(mainGroup)

            // 4. Create welcome messages
            repository.insertMessage(
                Message(
                    chatId = "main_group",
                    senderId = 1,
                    senderName = "المشرف العام (أبو مران)",
                    senderAvatar = "avatar_admin",
                    content = "السلام عليكم ورحمة الله وبركاته. أرحب بكم يا أهل مران الكرام وأعضاء هذا الملتقى المبارك. هذا التطبيق صمم خصيصاً للتواصل الأخوي المباشر، ومشاركة أخبار البلاد، والحفاظ على تراثنا وثقافتنا اليمنية الأصيلة. تفضلوا بطرح مشاركاتكم الطيبة.",
                    timestamp = System.currentTimeMillis() - 3600000
                )
            )
            repository.insertMessage(
                Message(
                    chatId = "main_group",
                    senderId = salehId,
                    senderName = "صالح المراني",
                    senderAvatar = "avatar_2",
                    content = "وعليكم السلام ورحمة الله وبركاته يا حيا الله بالمشرف وبكل الحاضرين! مبروك علينا هذا التطبيق الفخم والسرع والآمن، والحمد لله الذي جمعنا في هذا الملتقى الراقي 🌹",
                    timestamp = System.currentTimeMillis() - 1800000
                )
            )

            // 5. Seed some admin logs
            repository.insertLog(
                AdminLog(
                    adminName = "المشرف العام",
                    action = "إنشاء وتفعيل الغرفة الرئيسية للملتقى بنجاح",
                    timestamp = System.currentTimeMillis() - 3600000
                )
            )
        }
    }

    // --- Authentication Actions ---
    suspend fun registerUser(email: String, password: String, name: String): String? {
        if (email.isBlank() || password.isBlank() || name.isBlank()) return "الرجاء تعبئة جميع الحقول المطلوبة."

        // 1. If Supabase is configured, register via Supabase Auth first
        if (supabaseService.isConfigured) {
            val supabaseError = supabaseService.signUpWithSupabase(email, password, name)
            if (supabaseError != null) {
                return supabaseError
            }
        }

        // 2. Check if user already exists locally
        val existing = repository.getUserByEmail(email)
        if (existing != null) return "هذا البريد الإلكتروني مسجل بالفعل."

        // Determine if this is the first user (if database was empty somehow), make them Super Admin
        val allUsersList = repository.allUsers.first()
        val makeAdmin = allUsersList.isEmpty()

        val newUser = User(
            email = email,
            password = password,
            name = name,
            isSuperAdmin = makeAdmin,
            avatarUrl = "avatar_${(2..5).random()}"
        )
        val id = repository.insertUser(newUser).toInt()
        val userWithId = newUser.copy(id = id)
        currentUser = userWithId
        if (supabaseService.isConfigured) {
            viewModelScope.launch {
                supabaseService.syncUser(userWithId)
            }
        }
        return null
    }

    suspend fun loginUser(email: String, password: String): String? {
        if (email.isBlank() || password.isBlank()) return "الرجاء إدخال البريد الإلكتروني وكلمة المرور."

        // 1. If Supabase is configured, authenticate via Supabase Auth first
        if (supabaseService.isConfigured) {
            val supabaseError = supabaseService.signInWithSupabase(email, password)
            if (supabaseError != null) {
                return supabaseError
            }
            // Trigger background sync to get latest users from Cloud
            viewModelScope.launch {
                supabaseService.syncAll()
            }
        }

        // 2. Fetch local user by email
        var user = repository.getUserByEmail(email)

        // If authenticated on Supabase but local profile doesn't exist yet, create one
        if (user == null && supabaseService.isConfigured) {
            val allUsersList = repository.allUsers.first()
            val makeAdmin = allUsersList.isEmpty() || email == "admin@maran.com"
            val newUser = User(
                email = email,
                password = password,
                name = email.substringBefore("@"),
                isSuperAdmin = makeAdmin,
                avatarUrl = "avatar_${(2..5).random()}"
            )
            val id = repository.insertUser(newUser).toInt()
            user = newUser.copy(id = id)
            viewModelScope.launch {
                supabaseService.syncUser(user)
            }
        }

        return if (user != null) {
            if (user.isFrozen) {
                "بيانات الدخول غير صحيحة أو الحساب مجمد مؤقتاً."
            } else {
                currentUser = user
                // Set status to Online
                val updatedUser = user.copy(status = "متصل", lastSeen = System.currentTimeMillis())
                repository.updateUser(updatedUser)
                if (supabaseService.isConfigured) {
                    viewModelScope.launch {
                        supabaseService.syncUser(updatedUser)
                    }
                }
                null // Success!
            }
        } else {
            "بيانات الدخول غير صحيحة."
        }
    }

    fun logoutUser() {
        val user = currentUser
        if (user != null) {
            viewModelScope.launch {
                val updatedUser = user.copy(status = "غير متصل", lastSeen = System.currentTimeMillis())
                repository.updateUser(updatedUser)
                if (supabaseService.isConfigured) {
                    supabaseService.syncUser(updatedUser)
                }
                currentUser = null
                setChatId("main_group")
            }
        }
    }

    // --- Profile Management ---
    fun updateProfile(name: String, email: String, bio: String, status: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            val updated = user.copy(name = name, email = email, bio = bio, status = status)
            repository.updateUser(updated)
            currentUser = updated
            if (supabaseService.isConfigured) {
                supabaseService.syncUser(updated)
            }
        }
    }

    fun updatePassword(newPass: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            val updated = user.copy(password = newPass)
            repository.updateUser(updated)
            currentUser = updated
            if (supabaseService.isConfigured) {
                supabaseService.syncUser(updated)
            }
        }
    }

    fun saveCustomAvatar(avatarId: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            val updated = user.copy(avatarUrl = avatarId)
            repository.updateUser(updated)
            currentUser = updated
            if (supabaseService.isConfigured) {
                supabaseService.syncUser(updated)
            }
        }
    }

    fun updateCoverPhoto(coverId: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            val updated = user.copy(coverUrl = coverId)
            repository.updateUser(updated)
            currentUser = updated
            if (supabaseService.isConfigured) {
                supabaseService.syncUser(updated)
            }
        }
    }

    // --- Message Actions ---
    fun sendMessage(content: String, type: String = "TEXT", mediaUri: String? = null, replyToId: Int? = null, replyToContent: String? = null) {
        val user = currentUser ?: return
        viewModelScope.launch {
            val msg = Message(
                chatId = activeChatId,
                senderId = user.id,
                senderName = user.name,
                senderAvatar = user.avatarUrl,
                content = content,
                messageType = type,
                mediaUri = mediaUri,
                replyToId = replyToId,
                replyToContent = replyToContent
            )
            val generatedId = repository.insertMessage(msg).toInt()
            val finalMsg = msg.copy(id = generatedId)
            if (supabaseService.isConfigured) {
                supabaseService.syncMessage(finalMsg)
            }
        }
    }

    fun editMessage(msgId: Int, newContent: String) {
        viewModelScope.launch {
            val msg = repository.getMessageById(msgId) ?: return@launch
            if (msg.senderId == currentUser?.id || currentUser?.isSuperAdmin == true) {
                val updated = msg.copy(content = newContent, isEdited = true)
                repository.updateMessage(updated)
                if (supabaseService.isConfigured) {
                    supabaseService.syncMessage(updated)
                }

                if (currentUser?.isSuperAdmin == true && msg.senderId != currentUser?.id) {
                    repository.insertLog(
                        AdminLog(
                            adminName = currentUser?.name ?: "الأدمن",
                            action = "تعديل رسالة المستخدم ${msg.senderName}: $newContent"
                        )
                    )
                }
            }
        }
    }

    fun deleteMessageForAll(msgId: Int) {
        viewModelScope.launch {
            val msg = repository.getMessageById(msgId) ?: return@launch
            val updated = msg.copy(content = "تم حذف هذه الرسالة", isDeletedForAll = true)
            repository.updateMessage(updated)
            if (supabaseService.isConfigured) {
                supabaseService.syncMessage(updated)
            }

            if (currentUser?.isSuperAdmin == true) {
                repository.insertLog(
                    AdminLog(
                        adminName = currentUser?.name ?: "الأدمن",
                        action = "حذف رسالة للطرفين مرسلة من ${msg.senderName}"
                    )
                )
            }
        }
    }

    fun deleteMessageLocal(msgId: Int) {
        viewModelScope.launch {
            val msg = repository.getMessageById(msgId) ?: return@launch
            repository.deleteMessage(msg)
        }
    }

    fun togglePinMessage(msgId: Int) {
        viewModelScope.launch {
            val msg = repository.getMessageById(msgId) ?: return@launch
            val updated = msg.copy(isPinned = !msg.isPinned)
            repository.updateMessage(updated)
            if (supabaseService.isConfigured) {
                supabaseService.syncMessage(updated)
            }

            if (currentUser?.isSuperAdmin == true) {
                repository.insertLog(
                    AdminLog(
                        adminName = currentUser?.name ?: "الأدمن",
                        action = "تثبيت/إلغاء تثبيت رسالة لـ ${msg.senderName}"
                    )
                )
            }
        }
    }

    fun addReaction(msgId: Int, reaction: String) {
        viewModelScope.launch {
            val msg = repository.getMessageById(msgId) ?: return@launch
            // Standardizing reactions
            val updatedReactions = if (msg.reactions.contains(reaction)) {
                // Remove reaction if exists
                msg.reactions.replace(reaction, "").replace(",,", ",").trim(',')
            } else {
                if (msg.reactions.isEmpty()) reaction else "${msg.reactions},$reaction"
            }
            val updated = msg.copy(reactions = updatedReactions)
            repository.updateMessage(updated)
            if (supabaseService.isConfigured) {
                supabaseService.syncMessage(updated)
            }
        }
    }

    // --- Call Simulation ---
    fun startCall(user: User, type: String) {
        isCallActive = true
        activeCallType = type
        activeCallUser = user
        callDuration = 0
        isCallMuted = false
        isCallVideoPaused = false

        callJob = viewModelScope.launch {
            while (isCallActive) {
                delay(1000)
                callDuration++
            }
        }

        // Send a call log message
        sendMessage(
            content = "مكالمة ${if (type == "AUDIO") "صوتية" else "فيديو"} صادرة - ${if (type == "AUDIO") "📞" else "📹"}",
            type = if (type == "AUDIO") "CALL_AUDIO" else "CALL_VIDEO"
        )
    }

    fun endCall() {
        isCallActive = false
        callJob?.cancel()
        callJob = null

        val callUser = activeCallUser
        val type = activeCallType
        if (callUser != null && type != null) {
            viewModelScope.launch {
                // Log receiving simulation after call
                delay(1000)
                // Randomly add call info to chat
                val minutes = callDuration / 60
                val seconds = callDuration % 60
                val durationStr = String.format("%02d:%02d", minutes, seconds)
                sendMessage(
                    content = "انتهت المكالمة ${if (type == "AUDIO") "الصوتية" else "المرئية"}. المدة: $durationStr",
                    type = "TEXT"
                )
            }
        }

        activeCallUser = null
        activeCallType = null
    }

    // --- Groups Management ---
    fun createGroup(name: String, description: String, icon: String) {
        val user = currentUser ?: return
        viewModelScope.launch {
            val newGroup = GroupDetail(
                name = name,
                description = description,
                iconUrl = icon,
                adminIds = "${user.id}",
                memberIds = "${user.id}"
            )
            val groupId = repository.insertGroup(newGroup).toInt()
            val finalGroup = newGroup.copy(id = groupId)
            if (supabaseService.isConfigured) {
                supabaseService.syncGroup(finalGroup)
            }
            repository.insertLog(
                AdminLog(
                    adminName = user.name,
                    action = "تم إنشاء مجموعة جديدة باسم '$name'"
                )
            )
            setChatId("group_$groupId", groupDetail = finalGroup)
        }
    }

    fun inviteUserToGroup(userId: Int, groupId: Int) {
        viewModelScope.launch {
            val group = repository.getGroupById(groupId) ?: return@launch
            val members = group.memberIds.split(",").toMutableList()
            if (!members.contains("$userId")) {
                members.add("$userId")
                val updatedGroup = group.copy(memberIds = members.joinToString(","))
                repository.updateGroup(updatedGroup)
                activeGroupDetail = updatedGroup
                if (supabaseService.isConfigured) {
                    supabaseService.syncGroup(updatedGroup)
                }
                repository.insertLog(
                    AdminLog(
                        adminName = currentUser?.name ?: "العضو",
                        action = "دعوة مستخدم رقم $userId للانضمام لمجموعة ${group.name}"
                    )
                )
            }
        }
    }

    fun makeUserGroupAdmin(userId: Int, groupId: Int) {
        viewModelScope.launch {
            val group = repository.getGroupById(groupId) ?: return@launch
            val admins = group.adminIds.split(",").toMutableList()
            if (!admins.contains("$userId")) {
                admins.add("$userId")
                val updatedGroup = group.copy(adminIds = admins.joinToString(","))
                repository.updateGroup(updatedGroup)
                activeGroupDetail = updatedGroup
                if (supabaseService.isConfigured) {
                    supabaseService.syncGroup(updatedGroup)
                }
            }
        }
    }

    // --- Reports ---
    fun fileReport(reportedUser: String, reason: String) {
        val reporter = currentUser?.name ?: "مجهول"
        viewModelScope.launch {
            val rep = Report(
                reportedBy = reporter,
                reportedUser = reportedUser,
                reason = reason
            )
            val generatedId = repository.insertReport(rep).toInt()
            val finalRep = rep.copy(id = generatedId)
            if (supabaseService.isConfigured) {
                supabaseService.syncReport(finalRep)
            }
        }
    }

    // --- Super Admin Control Actions ---
    fun freezeUser(user: User) {
        if (currentUser?.isSuperAdmin != true) return
        viewModelScope.launch {
            val updated = user.copy(isFrozen = !user.isFrozen)
            repository.updateUser(updated)
            if (supabaseService.isConfigured) {
                supabaseService.syncUser(updated)
            }
            repository.insertLog(
                AdminLog(
                    adminName = currentUser?.name ?: "الأدمن",
                    action = "تغيير حالة تجميد الحساب لـ ${user.name} إلى ${if (updated.isFrozen) "مجمد" else "نشط"}"
                )
            )
        }
    }

    fun deleteUserAccount(user: User) {
        if (currentUser?.isSuperAdmin != true) return
        viewModelScope.launch {
            // We simulate deletion by setting a deleted profile status or updating name
            val updated = user.copy(
                name = "حساب محذوف",
                isFrozen = true,
                bio = "تم إيقاف هذا الحساب بواسطة الإدارة العام للملتقى."
            )
            repository.updateUser(updated)
            if (supabaseService.isConfigured) {
                supabaseService.syncUser(updated)
            }
            repository.insertLog(
                AdminLog(
                    adminName = currentUser?.name ?: "الأدمن",
                    action = "إيقاف وحذف حساب المستخدم ${user.name} نهائياً"
                )
            )
        }
    }

    fun resolveReport(report: Report) {
        if (currentUser?.isSuperAdmin != true) return
        viewModelScope.launch {
            val updated = report.copy(status = "تم الحل")
            repository.updateReport(updated)
            if (supabaseService.isConfigured) {
                supabaseService.syncReport(updated)
            }
            repository.insertLog(
                AdminLog(
                    adminName = currentUser?.name ?: "الأدمن",
                    action = "مراجعة وحل البلاغ رقم ${report.id} المقدم ضد ${report.reportedUser}"
                )
            )
        }
    }

    fun changeAppBranding(newName: String, newLogo: String) {
        if (currentUser?.isSuperAdmin != true) return
        appNameState = newName
        appLogoState = newLogo
        viewModelScope.launch {
            repository.insertLog(
                AdminLog(
                    adminName = currentUser?.name ?: "الأدمن",
                    action = "تحديث الهوية البصرية للتطبيق: الاسم ($newName)، الشعار ($newLogo)"
                )
            )
        }
    }

    fun sendBroadcastNotification(content: String) {
        if (currentUser?.isSuperAdmin != true) return
        viewModelScope.launch {
            // Inserts a global broadcast message in the main chat room
            val broadcastMsg = Message(
                chatId = "main_group",
                senderId = currentUser?.id ?: 1,
                senderName = "📢 إعلان إداري عاجل",
                senderAvatar = "avatar_admin",
                content = content,
                timestamp = System.currentTimeMillis()
            )
            val generatedId = repository.insertMessage(broadcastMsg).toInt()
            val finalMsg = broadcastMsg.copy(id = generatedId)
            if (supabaseService.isConfigured) {
                supabaseService.syncMessage(finalMsg)
            }
            repository.insertLog(
                AdminLog(
                    adminName = currentUser?.name ?: "الأدمن",
                    action = "إرسال إشعار عام وبث رسالة عاجلة لكافة الأعضاء"
                )
            )
        }
    }

    // --- Simulated Incoming Messages for Realism ---
    private fun simulatePeriodicIncomingMessages() {
        viewModelScope.launch {
            while (true) {
                delay(120000) // Every 2 minutes
                val activeUsers = allUsers.value.filter { !it.isSuperAdmin && it.id != currentUser?.id && !it.isFrozen }
                if (activeUsers.isNotEmpty() && currentUser != null) {
                    val sender = activeUsers.random()

                    val communityPhrases = listOf(
                        "يا أهل مران الكرام، ما رأيكم في تنسيق اجتماع الأسبوع القادم في ديوان آل مران؟",
                        "يا حيا الله بالجميع، حبوب البن الخولاني هالسنة ما شاء الله جودة ممتازة جداً ☕🇾🇪",
                        "مساء الخير والسرور لأهل صعدة الشموخ وأهل مران الغاليين 🌸",
                        "من يشاركنا بيتين شعر من التراث اليمني في هذا المساء الجميل؟",
                        "الحمد لله على نعمة الأمن والأمان والترابط الأخوي بيننا في هذا الملتقى الطيب.",
                        "هل من أخبار عن الأمطار والسيول في وديان صعدة ومران اليوم؟ 🌧️",
                        "جمعة مباركة مقدماً على جميع الإخوة والأخوات الكرام في ملتقانا."
                    )

                    val chatToPost = if (Math.random() > 0.4) "main_group" else "private_${Math.min(currentUser!!.id, sender.id)}_${Math.max(currentUser!!.id, sender.id)}"

                    // Create automated simulated message
                    val simulatedMsg = Message(
                        chatId = chatToPost,
                        senderId = sender.id,
                        senderName = sender.name,
                        senderAvatar = sender.avatarUrl,
                        content = communityPhrases.random(),
                        timestamp = System.currentTimeMillis()
                    )

                    repository.insertMessage(simulatedMsg)
                }
            }
        }
    }
}
