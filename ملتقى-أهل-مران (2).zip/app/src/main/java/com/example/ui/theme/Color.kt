package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Yemeni Heritage Palette - Deep Agate Green & Antique Gold
val YemeniGreenPrimary = Color(0xFF0A5C36)
val YemeniGreenSecondary = Color(0xFF1B8A5A)
val MaranGold = Color(0xFFD4AF37) // Antique Gold
val WarmSandLight = Color(0xFFF7F5F0)
val CharcoalDark = Color(0xFF0F171E) // Premium Dark slate/obsidian

// Dark Theme Colors
val Green80 = Color(0xFF5ED39D)
val Gold80 = Color(0xFFFFD700)
val Slate80 = Color(0xFF23313F)

// Light Theme Colors
val Green40 = Color(0xFF0A5C36)
val Gold40 = Color(0xFFB8860B)
val Slate40 = Color(0xFFF1EDE4)
val DarkGreenText = Color(0xFF042616)
val BackgroundDark = Color(0xFF0E1621) // Telegram style dark
val SurfaceDark = Color(0xFF182533)
val BackgroundLight = Color(0xFFF4F3EF)
val SurfaceLight = Color(0xFFFFFFFF)
