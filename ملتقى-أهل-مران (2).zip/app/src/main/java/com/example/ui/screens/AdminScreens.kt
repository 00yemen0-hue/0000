package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdminLog
import com.example.data.model.Report
import com.example.data.model.User
import com.example.ui.components.CustomAvatarView
import com.example.ui.components.YemeniEmblem
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreens(
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    if (viewModel.currentUser?.isSuperAdmin != true) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("عذراً، هذه الصفحة مخصصة للمشرف العام فقط.")
        }
        return
    }

    val users by viewModel.allUsers.collectAsState()
    val logs by viewModel.adminLogs.collectAsState()
    val reports by viewModel.reports.collectAsState()

    var activeTab by remember { mutableStateOf("dashboard") } // dashboard, users, reports, settings, logs

    val colors = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("لوحة إدارة ملتقى مران", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("صلاحية المشرف العام النشطة", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.surface)
            )
        },
        bottomBar = {
            // Admin bottom selector bar
            NavigationBar(modifier = Modifier.fillMaxWidth().navigationBarsPadding()) {
                NavigationBarItem(
                    selected = activeTab == "dashboard",
                    onClick = { activeTab = "dashboard" },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                    label = { Text("الرئيسية", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "users",
                    onClick = { activeTab = "users" },
                    icon = { Icon(Icons.Default.People, contentDescription = null) },
                    label = { Text("الأعضاء", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "reports",
                    onClick = { activeTab = "reports" },
                    icon = { Icon(Icons.Default.Report, contentDescription = null) },
                    label = { Text("البلاغات", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "settings",
                    onClick = { activeTab = "settings" },
                    icon = { Icon(Icons.Default.Palette, contentDescription = null) },
                    label = { Text("الهوية", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = activeTab == "logs",
                    onClick = { activeTab = "logs" },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text("السجلات", fontSize = 11.sp) }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(colors.surfaceColorAtElevation(1.dp))
        ) {
            when (activeTab) {
                "dashboard" -> AdminDashboardTab(viewModel, users, logs)
                "users" -> AdminUsersTab(viewModel, users)
                "reports" -> AdminReportsTab(viewModel, reports)
                "settings" -> AdminSettingsTab(viewModel)
                "logs" -> AdminLogsTab(logs, colors)
            }
        }
    }
}

@Composable
fun AdminDashboardTab(
    viewModel: ChatViewModel,
    users: List<User>,
    logs: List<AdminLog>
) {
    val colors = MaterialTheme.colorScheme
    var broadcastText by remember { mutableStateOf("") }
    var broadcastSuccess by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("إحصائيات ملتقى مران", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Card 1
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = colors.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.People, contentDescription = null, tint = colors.onPrimaryContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("إجمالي الأعضاء", style = MaterialTheme.typography.bodySmall.copy(color = colors.onPrimaryContainer))
                        Text("${users.size}", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = colors.onPrimaryContainer))
                    }
                }

                // Card 2
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = colors.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(Icons.Default.Forum, contentDescription = null, tint = colors.onSecondaryContainer)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("الغرف والمجالس", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSecondaryContainer))
                        Text("3 مجالس", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = colors.onSecondaryContainer))
                    }
                }
            }
        }

        // Global Push Notification Broadcasting board
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, colors.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "إرسال إشعار وبث عام عاجل",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = colors.primary)
                    )
                    Text(
                        "سيتم بث الرسالة لجميع الإخوة المنضمين لغرفة ملتقى أهل مران كإعلان إداري مثبت.",
                        style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = broadcastText,
                        onValueChange = { broadcastText = it },
                        placeholder = { Text("اكتب نص الإعلان الإداري هنا...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_broadcast_input"),
                        shape = RoundedCornerShape(8.dp),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (broadcastText.isNotBlank()) {
                                viewModel.sendBroadcastNotification(broadcastText)
                                broadcastText = ""
                                broadcastSuccess = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("بث وتعميم الإشعار الآن")
                    }

                    if (broadcastSuccess) {
                        Text(
                            "تم بث الإشعار بنجاح وإدراجه في مجلس مران العام!",
                            color = colors.primary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 6.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Recent Logs overview
        item {
            Text("العمليات الأخيرة بالنظام", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        }

        items(logs.take(3)) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = colors.primary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(log.action, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = android.text.format.DateFormat.format("hh:mm a - yyyy/MM/dd", log.timestamp).toString(),
                            fontSize = 8.sp,
                            color = colors.onSurface.copy(alpha = 0.4f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUsersTab(
    viewModel: ChatViewModel,
    users: List<User>
) {
    val colors = MaterialTheme.colorScheme

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("إدارة شؤون الأعضاء", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("تجميد، تعديل أو إيقاف أي عضو يخالف شروط الملتقى.", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)))
        }

        items(users) { user ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (user.isFrozen) colors.error else Color.Transparent
                )
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CustomAvatarView(
                        modifier = Modifier.size(44.dp),
                        skinColorHex = if (user.avatarUrl.startsWith("#")) user.avatarUrl else "#D2B48C"
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(user.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            if (user.isSuperAdmin) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Badge(containerColor = colors.tertiary) { Text("مشرف عام", fontSize = 8.sp, color = colors.onTertiary) }
                            }
                        }
                        Text(user.email, fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.5f))
                        if (user.isFrozen) {
                            Text("🚫 الحساب مجمد حالياً", color = colors.error, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Admin buttons
                    if (!user.isSuperAdmin) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Freeze Toggle Button
                            Button(
                                onClick = { viewModel.freezeUser(user) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (user.isFrozen) colors.primary else colors.errorContainer,
                                    contentColor = if (user.isFrozen) colors.onPrimary else colors.onErrorContainer
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(if (user.isFrozen) "تنشيط" else "تجميد", fontSize = 10.sp)
                            }

                            // Delete simulation
                            IconButton(onClick = { viewModel.deleteUserAccount(user) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف الحساب", tint = colors.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminReportsTab(
    viewModel: ChatViewModel,
    reports: List<Report>
) {
    val colors = MaterialTheme.colorScheme

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("مراجعة بلاغات الأعضاء", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text("التحقق من المحتوى المخالف والبلاغات المرفوعة ضد الإساءة.", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)))
        }

        if (reports.isEmpty()) {
            item {
                Column(
                    modifier = Modifier.fillParentMaxSize().padding(top = 100.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = colors.primary, modifier = Modifier.size(60.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("الحمد لله! لا توجد بلاغات معلقة حالياً.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            items(reports) { rpt ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = colors.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("البلاغ ضد: ${rpt.reportedUser}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Badge(containerColor = if (rpt.status == "تم الحل") colors.primary else colors.errorContainer) {
                                Text(rpt.status, color = if (rpt.status == "تم الحل") colors.onPrimary else colors.onErrorContainer)
                            }
                        }
                        Text("الشاكي: ${rpt.reportedBy}", fontSize = 11.sp, color = colors.onSurface.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("سبب البلاغ: ${rpt.reason}", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        if (rpt.status != "تم الحل") {
                            Button(
                                onClick = { viewModel.resolveReport(rpt) },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("تحديد كتم الحل", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminSettingsTab(
    viewModel: ChatViewModel
) {
    val colors = MaterialTheme.colorScheme
    var newAppName by remember { mutableStateOf(viewModel.appNameState) }
    var selectedLogoStyle by remember { mutableStateOf(viewModel.appLogoState) }
    var editSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("تحديث الهوية البصرية وشعار التطبيق", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("يتم تطبيق هذه الإعدادات على جميع مستخدمي ملتقى مران فوراً.", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)), modifier = Modifier.padding(bottom = 16.dp))

        OutlinedTextField(
            value = newAppName,
            onValueChange = { newAppName = it },
            label = { Text("اسم التطبيق المعتمد") },
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            shape = RoundedCornerShape(8.dp)
        )

        Text("نمط وشعار الملتقى:", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 8.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf("emblem_heritage" to "تراثي تقليدي", "emblem_classic" to "كلاسيكي فاخر", "emblem_modern" to "حديث مبسط").forEach { (style, label) ->
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedLogoStyle = style }
                        .border(
                            width = 2.dp,
                            color = if (selectedLogoStyle == style) colors.primary else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = colors.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        YemeniEmblem(modifier = Modifier.size(50.dp), style = style)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(label, fontSize = 10.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                viewModel.changeAppBranding(newAppName, selectedLogoStyle)
                editSuccess = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("حفظ وتعميم التعديلات على التطبيق")
        }

        if (editSuccess) {
            Text(
                "تم حفظ وتطبيق التعديلات بنجاح!",
                color = colors.primary,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 10.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun AdminLogsTab(
    logs: List<AdminLog>,
    colors: ColorScheme
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("سجل عمليات المشرفين (Logs)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("سجل أمني غير قابل للتعديل لكافة العمليات الإدارية المتخذة.", style = MaterialTheme.typography.bodySmall.copy(color = colors.onSurface.copy(alpha = 0.5f)), modifier = Modifier.padding(bottom = 12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = colors.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("بواسطة: ${log.adminName}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = colors.primary))
                            Text(
                                text = android.text.format.DateFormat.format("hh:mm:ss a", log.timestamp).toString(),
                                fontSize = 8.sp,
                                color = colors.onSurface.copy(alpha = 0.4f)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(log.action, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
